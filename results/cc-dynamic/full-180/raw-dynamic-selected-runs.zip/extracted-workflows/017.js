export const meta = {
  name: "travelplanner-pa-7day",
  description: "Plan a 7-day, 3-city Pennsylvania itinerary for 1 traveler from Charlotte NC, Mar 6-12 2022, budget $5100",
  phases: 3,
};

const COMMON = `
You are helping build a TravelPlanner itinerary.
Trip: 1 traveler, departs Charlotte (North Carolina), visits 3 Pennsylvania cities,
March 6-12 2022 (7 days), total budget $5100.
Route already fixed: Day1-2 Philadelphia, Day3-4 Harrisburg, Day5-6 Pittsburgh, Day7 fly home from Pittsburgh.
Each city is stayed exactly 2 nights.

HARD RULES:
- Use at most 5 tool calls total. If a tool returns nothing, try ONE alternative then move on.
- Do not loop or retry. Be fast. Report compactly.
`;

const cityAgent = (city, nights) =>
  agent(
    `${COMMON}
Your job: gather options for ${city}, Pennsylvania (${nights} nights stay for the 1 traveler).

Call exactly these tools once each:
1. mcp__travelplanner__search_accommodations for "${city}"
2. mcp__travelplanner__search_restaurants for "${city}"
3. mcp__travelplanner__search_attractions for "${city}"

Then report, as plain compact text:
- ACCOMMODATION: pick ONE valid option. It MUST have minimum nights <= ${nights} and maximum occupancy >= 1.
  Report exact NAME, price per night, room type, minimum nights, max occupancy, house rules.
  Also list 2 backup options with the same fields.
- RESTAURANTS: list 8 distinct restaurants with exact NAME and average cost, cheaper but varied cuisines.
- ATTRACTIONS: list 6 distinct attractions with exact NAME.
Use the exact names as returned by the tools. Do not invent anything.`,
    { model: "sonnet", description: `Research ${city}` }
  );

const cityData = await phase("city-research", () =>
  parallel([
    cityAgent("Philadelphia", 2),
    cityAgent("Harrisburg", 2),
    cityAgent("Pittsburgh", 2),
  ])
);

const transport = await phase("transport", () =>
  agent(
    `${COMMON}
Your job: get ground transportation between the Pennsylvania cities.

Call exactly these tools:
1. mcp__travelplanner__compute_distance origin "Philadelphia" destination "Harrisburg" mode "taxi"
2. mcp__travelplanner__compute_distance origin "Philadelphia" destination "Harrisburg" mode "driving"
3. mcp__travelplanner__compute_distance origin "Harrisburg" destination "Pittsburgh" mode "taxi"
4. mcp__travelplanner__compute_distance origin "Harrisburg" destination "Pittsburgh" mode "driving"

Report each result VERBATIM in the exact string format the tool returns (e.g.
"self-driving, from A to B, duration: X hours Y mins, distance: Z km, cost: $N"
or "taxi, from A to B, duration: ..., distance: ..., cost: ...").
Report exact durations, distances and costs. Nothing else.`,
    { model: "sonnet", description: "Intercity transport" }
  )
);

const FLIGHTS = `
Flights already retrieved (do NOT re-search):
Outbound 2022-03-06 Charlotte -> Philadelphia:
  F3660359 $162 dep 09:29 arr 10:55
  F3663345 $219 dep 07:33 arr 09:09
  F3669893 $139 dep 10:54 arr 12:47
  F3660962 $126 dep 18:52 arr 20:21
Return 2022-03-12 Pittsburgh -> Charlotte:
  F4059364 $104 dep 11:32 arr 13:29
  F3689870 $147 dep 08:29 arr 10:47
  F4053867 $160 dep 12:31 arr 14:25
Recommended: outbound F3663345 (arrives 09:09) and return F4053867 (dep 12:31).
`;

const final = await phase("synthesize", () =>
  agent(
    `You are assembling the FINAL TravelPlanner JSON answer. Make ZERO tool calls.

Trip: 1 traveler, from Charlotte (North Carolina), 3 Pennsylvania cities, 2022-03-06 to 2022-03-12, budget $5100.
Route: Day1 fly Charlotte->Philadelphia; Day2 Philadelphia; Day3 Philadelphia->Harrisburg (ground);
Day4 Harrisburg; Day5 Harrisburg->Pittsburgh (ground); Day6 Pittsburgh; Day7 fly Pittsburgh->Charlotte.

${FLIGHTS}

Intercity ground transport data:
${transport}

City research results:
--- PHILADELPHIA ---
${cityData[0]}
--- HARRISBURG ---
${cityData[1]}
--- PITTSBURGH ---
${cityData[2]}

Rules you MUST satisfy:
- Use ONLY exact names from the research above. Never invent a name.
- A restaurant may be used AT MOST ONCE across the whole 7 days. Same for attractions.
- Restaurants and attractions on a given day must be in that day's city (on travel days use the destination city).
- Day 1 breakfast is "-"; with a 09:09 arrival, include an attraction, lunch and dinner in Philadelphia.
- Day 7: accommodation "-"; include breakfast in Pittsburgh, then "-" for lunch and dinner and "-" for attraction.
- accommodation: same accommodation for both nights in a city; Day 3 accommodation = the Harrisburg one, Day 5 = the Pittsburgh one, Day 1 and 2 = the Philadelphia one, Day 4 = Harrisburg one, Day 6 = Pittsburgh one.
- transportation strings: flights as "Flight Number: F3663345, from Charlotte to Philadelphia, Departure Time: 07:33, Arrival Time: 09:09".
  Ground legs use the tool's format, e.g. "Self-driving, from Philadelphia to Harrisburg, duration: 1 hour 47 mins, distance: 170 km, cost: $14"
  (capitalize as "Self-driving" / "Taxi"). Use "-" on non-travel days (Day 2, 4, 6).
- Keep total estimated cost for the 1 person under $5100.

Output the JSON object inside a single \`\`\`json code block with this exact shape and 7 plan entries:
{"idx": 46, "query": "Please help me craft a 7-day travel plan for one person departing from Charlotte in North Carolina, visiting 3 cities in Pennsylvania. The travel dates are from March 6th to March 12th, 2022. The allocated budget for this trip is $5,100.", "plan": [{"day":1,"current_city":"from Charlotte to Philadelphia","transportation":"...","breakfast":"-","attraction":"Name, Philadelphia;","lunch":"Name, Philadelphia","dinner":"Name, Philadelphia","accommodation":"Name, Philadelphia"}]}

current_city values: Day1 "from Charlotte to Philadelphia", Day2 "Philadelphia", Day3 "from Philadelphia to Harrisburg", Day4 "Harrisburg", Day5 "from Harrisburg to Pittsburgh", Day6 "Pittsburgh", Day7 "from Pittsburgh to Charlotte".
attraction entries are semicolon separated and each ends with ";" e.g. "A, Philadelphia;B, Philadelphia;". Use 1-2 attractions per day.
After the JSON block, add one short line with the rough total cost breakdown.`,
    { model: "sonnet", description: "Assemble final JSON" }
  )
);

return final;
