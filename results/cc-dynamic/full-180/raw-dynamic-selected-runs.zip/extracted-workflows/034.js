export const meta = {
  name: "travelplanner-146",
  description: "Plan a 5-day, 4-person road trip from Evansville to 2 Texas cities (Texarkana + Dallas), Mar 12-16 2022, budget $9500, entire-room no-party-restriction lodging, no flights.",
  phases: ["gather", "assemble"]
};

const RULES = `
Trip facts (already fixed, do not re-derive):
- Travelers: 4. Dates: 2022-03-12 to 2022-03-16 (5 days). Budget $9500. No flights (self-driving only).
- Route: Day1 Evansville -> Texarkana (self-driving, from Evansville to Texarkana, duration: 8 hours 45 mins, distance: 889 km, cost: 44).
  Day3 Texarkana -> Dallas (self-driving, from Texarkana to Dallas, duration: 2 hours 43 mins, distance: 289 km, cost: 14).
  Day5 Dallas -> Evansville (self-driving, from Dallas to Evansville, duration: 11 hours 14 mins, distance: 1,169 km, cost: 58).
- Accommodations MUST be room type "Entire home/apt" AND house rules must NOT include "No parties". Also minimum nights must be <= the nights we stay (2 nights in Texarkana, 2 nights in Dallas).
LIMITS: at most 5 tool calls. If a search returns nothing, try ONE alternative then move on.
`;

const gather = (city, nights) => `You are gathering TravelPlanner data for ${city}, Texas.
${RULES}
We stay ${nights} nights in ${city}.

Do exactly these MCP tool calls (max 5 total):
1. mcp__travelplanner__search_accommodations with city="${city}"
2. mcp__travelplanner__search_restaurants with city="${city}"
3. mcp__travelplanner__search_attractions with city="${city}"

Then report back CONCISELY as plain text:
- ACCOMMODATION: pick ONE valid option (room type exactly "Entire home/apt", house rules do NOT contain "No parties", minimum nights <= ${nights}, maximum occupancy >= 4 if listed). Give its exact NAME, price per night, room type, house rules, minimum nights, maximum occupancy. If several qualify, pick the cheapest that fits 4 people. Also give ONE backup option with the same fields.
- RESTAURANTS: exact names + average cost of 6 distinct restaurants (cheap-to-moderate preferred).
- ATTRACTIONS: exact names of 6 distinct attractions.
Use exact names as returned by the tools. Do not invent anything. Do not write files.`;

const [tex, dal] = await parallel([
  () => agent(gather("Texarkana", 2), { name: "texarkana-scout" }),
  () => agent(gather("Dallas", 2), { name: "dallas-scout" })
]);

const assembled = await agent(`Assemble the final TravelPlanner itinerary JSON.
${RULES}

Data gathered for Texarkana:
${tex}

Data gathered for Dallas:
${dal}

Build the plan with this day structure:
- Day 1 (2022-03-12): current_city "from Evansville to Texarkana", transportation = the exact self-driving string for Evansville->Texarkana. Long drive day: breakfast "-", attraction "-", lunch "-", dinner a Texarkana restaurant, accommodation the Texarkana pick.
- Day 2 (2022-03-13): current_city "Texarkana", transportation "-", breakfast/lunch/dinner distinct Texarkana restaurants, attraction 2 Texarkana attractions, accommodation the Texarkana pick.
- Day 3 (2022-03-14): current_city "from Texarkana to Dallas", transportation = exact self-driving string Texarkana->Dallas, breakfast a Texarkana restaurant, attraction 1-2 Dallas attractions, lunch and dinner Dallas restaurants, accommodation the Dallas pick.
- Day 4 (2022-03-15): current_city "Dallas", transportation "-", breakfast/lunch/dinner distinct Dallas restaurants, attraction 2 Dallas attractions, accommodation the Dallas pick.
- Day 5 (2022-03-16): current_city "from Dallas to Evansville", transportation = exact self-driving string Dallas->Evansville, breakfast a Dallas restaurant, attraction "-", lunch "-", dinner "-", accommodation "-".

Rules: never reuse the same restaurant twice anywhere in the plan. Attractions must be unique across the whole plan. Format attraction as "Name, City;Name, City;". Meals and accommodation as "Name, City".
Do a quick budget sanity check inline (driving 44+14+58=116 total for the group; lodging = nightly price x 2 nights x 2 cities, assume 1 unit sleeping 4; meals = avg cost x 4 people). Total must be under $9500 — if not, swap to cheaper picks.

Make ZERO tool calls. Output ONLY the final JSON object (no code fence, no commentary) with keys "idx" (146), "query" (exactly: Can you help design a 5-day travel plan for a group of 4, starting from Evansville and visiting 2 cities in Texas? The trip spans from March 12th to March 16th, 2022. Our budget is now $9,500, and for accommodations, we require entire rooms that do not restrict parties. Also, note that we prefer to avoid airline transportation.) and "plan" (array of 5 day objects with keys day, current_city, transportation, breakfast, attraction, lunch, dinner, accommodation). After the JSON, on a new line, print "BUDGET_TOTAL: $<number>".`, { name: "assembler" });

return assembled;
