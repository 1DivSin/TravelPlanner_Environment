export const meta = {
  name: "travelplanner-idx83",
  description: "Plan a 5-day, 2-city New York itinerary from Denver (Mar 18-22, 2022, 2 people, $6300)",
  phases: 2,
};

const COMMON = `You are gathering TravelPlanner data. Use ONLY the mcp__travelplanner__* tools.
HARD LIMIT: at most 4 tool calls total. If a tool returns nothing, try ONE alternative then stop.
Do NOT write files. Report back as compact plain text lists.`;

const nyPrompt = `${COMMON}

City: "New York" (NYC). Trip dates: 2022-03-18 to 2022-03-20 (2 nights). 2 travelers.
Traveler cuisine preferences: Mexican and Indian.

Do exactly this:
1. mcp__travelplanner__search_restaurants(city="New York")
2. mcp__travelplanner__search_attractions(city="New York")

Then report:
- RESTAURANTS: up to 8 rows, PREFERRING ones whose Cuisines field includes Mexican or Indian.
  Format one per line: "<exact Name> | <Cuisines> | avg cost <N>"
- ATTRACTIONS: up to 6 rows, format "<exact Name>"
Use the EXACT names as returned by the tool (do not paraphrase, do not drop punctuation).`;

const bufPrompt = `${COMMON}

City: "Buffalo", New York. Trip dates: 2022-03-20 to 2022-03-22 (2 nights). 2 travelers.
Traveler cuisine preferences: Mexican and Indian.

Do exactly this:
1. mcp__travelplanner__search_accommodations(city="Buffalo")
2. mcp__travelplanner__search_restaurants(city="Buffalo")
3. mcp__travelplanner__search_attractions(city="Buffalo")

Then report:
- ACCOMMODATIONS: every row that satisfies BOTH "maximum occupancy >= 2" AND "minimum nights <= 2".
  Format one per line: "<exact Name> | price <N>/night | <room type> | min nights <N> | max occupancy <N> | rules: <house_rules>"
  If none qualify, say "NONE QUALIFY" and list the 3 cheapest rows anyway with the same fields.
- RESTAURANTS: up to 8 rows, PREFERRING ones whose Cuisines field includes Mexican or Indian.
  Format one per line: "<exact Name> | <Cuisines> | avg cost <N>"
- ATTRACTIONS: up to 6 rows, format "<exact Name>"
Use the EXACT names as returned by the tool (do not paraphrase, do not drop punctuation).`;

const [ny, buf] = await parallel([
  () => agent(nyPrompt, { name: "nyc-scout", description: "Scout NYC restaurants and attractions" }),
  () => agent(bufPrompt, { name: "buffalo-scout", description: "Scout Buffalo stay food sights" }),
]);

const assemblePrompt = `You are assembling a final TravelPlanner itinerary JSON. Do NOT call any tools. Do NOT write files.
Reason from the data given below only. Output ONLY a JSON object in a \`\`\`json code block.

TRIP: 5 days, 2 people, origin Denver, 2 cities in New York state, 2022-03-18 .. 2022-03-22.
Cuisine preference: Mexican and Indian. Total budget: $6300.

FIXED ROUTE AND TRANSPORT (already verified by tool calls, use these strings VERBATIM):
- Day 1 (2022-03-18) Denver -> New York:
  "Flight Number: F3909302, from Denver to New York, Departure Time: 07:33, Arrival Time: 13:58"  (price 353 per person)
- Day 2 (2022-03-19) stay in New York: transportation "-"
- Day 3 (2022-03-20) New York -> Buffalo:
  "Flight Number: F3651211, from New York to Buffalo, Departure Time: 09:47, Arrival Time: 11:10"  (price 90 per person)
- Day 4 (2022-03-21) stay in Buffalo: transportation "-"
- Day 5 (2022-03-22) Buffalo -> Denver:
  "Flight Number: F3981763, from Buffalo to Denver, Departure Time: 05:59, Arrival Time: 07:42"  (price 362 per person)
Flights subtotal for 2 people = (353+90+362)*2 = 1610.

NEW YORK ACCOMMODATION (already verified, use verbatim, 2 nights = nights of Day 1 and Day 2):
  "A Contemporary Homelike Stay in the Best of BK" | price 228/night | Entire home/apt | min nights 2 | max occupancy 2
  -> 228 * 2 nights = 456. Accommodation string must be exactly: "A Contemporary Homelike Stay in the Best of BK, New York"

NEW YORK RESTAURANTS AND ATTRACTIONS (from scout):
${ny}

BUFFALO ACCOMMODATION, RESTAURANTS AND ATTRACTIONS (from scout):
${buf}

RULES YOU MUST SATISFY:
1. Pick ONE Buffalo accommodation with maximum occupancy >= 2 and minimum nights <= 2 (2 nights: Day 3 and Day 4 nights). Same accommodation both nights.
2. Day 5 accommodation is "-" (flying home that morning). Day 5 breakfast is "-" too (05:59 departure).
3. Every restaurant name must be used AT MOST ONCE across the entire 5-day plan. Never repeat a restaurant.
4. Every attraction must belong to the city you are in that day. Attraction field format: "Name, City;Another Name, City" (semicolon separated, city after each name).
5. Meals: Day 1 breakfast "-" (early flight). Otherwise fill breakfast/lunch/dinner with real restaurant names from the lists, formatted "<Name>, <City>". Favor Mexican and Indian cuisine restaurants.
6. current_city values EXACTLY:
   Day 1: "from Denver to New York"
   Day 2: "New York"
   Day 3: "from New York to Buffalo"
   Day 4: "Buffalo"
   Day 5: "from Buffalo to Denver"
7. Total cost (flights 1610 + NY accom 456 + Buffalo accom for 2 nights + meals for 2 people + attractions) must stay under 6300. Meal cost = avg cost * 2 people. Verify mentally; if over, pick cheaper restaurants.
8. Each day: 1-2 attractions. Day 5 attraction may be "-" given the 05:59 flight.
9. Use EXACT names from the scout data. Do not invent names.

Output shape EXACTLY (no extra keys, no commentary outside the code block):
\`\`\`json
{
  "idx": 83,
  "query": "Can you assist with crafting a 5-day travel itinerary for 2 people, originating from Denver and featuring 2 cities in New York? The itinerary will run from March 18th to March 22nd, 2022. Mexican and Indian cuisine are our preferred choices of food. Considering the budget, we have set it to $6,300.",
  "plan": [ { "day": 1, "current_city": "...", "transportation": "...", "breakfast": "...", "attraction": "...", "lunch": "...", "dinner": "...", "accommodation": "..." } ]
}
\`\`\``;

const final = await agent(assemblePrompt, {
  name: "itinerary-assembler",
  description: "Assemble final itinerary JSON",
});

console.log(final);
