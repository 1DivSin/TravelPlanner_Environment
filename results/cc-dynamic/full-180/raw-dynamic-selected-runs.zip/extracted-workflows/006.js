export const meta = {
  name: "tp-idx18-denver-palm-springs",
  description: "Plan a 3-day Denver to Palm Springs itinerary (Mar 27-29 2022, 1 person, $2200) using TravelPlanner tools",
  phases: 2
};

const asText = (r) => {
  if (r == null) return "";
  if (typeof r === "string") return r;
  if (typeof r.result === "string") return r.result;
  if (typeof r.output === "string") return r.output;
  if (typeof r.text === "string") return r.text;
  return JSON.stringify(r);
};

const TRIP = "TRIP: 1 traveler, Denver -> Palm Springs, depart 2022-03-27, return 2022-03-29 (3 days, 2 nights). Total budget $2200.";

const HARD_RULES = [
  "Make AT MOST 4 tool calls total.",
  "If a tool returns nothing useful, make ONE alternative call and then stop.",
  "Never repeat the same call. Never loop.",
  "Report values verbatim from tool output (exact names, exact numbers). Do not invent data.",
  "Answer as a compact plain-text list. No preamble, no commentary, no tables."
].join(" ");

const flightPrompt = TRIP + "\nYou are the FLIGHT scout. " + HARD_RULES + "\n\nCalls to make:\n1. mcp__travelplanner__search_flights origin \"Denver\", destination \"Palm Springs\", departure_date \"2022-03-27\"\n2. mcp__travelplanner__search_flights origin \"Palm Springs\", destination \"Denver\", departure_date \"2022-03-29\"\n\nIf a direction returns no flights, make ONE alternative call to mcp__travelplanner__compute_distance for that city pair with mode \"taxi\" and report distance/duration/cost instead.\n\nFor EACH direction report the 3 cheapest options, one per line, exactly like:\nOUTBOUND | Flight Number: <id> | from <OriginCity> to <DestCity> | Departure Time: <HH:MM> | Arrival Time: <HH:MM> | Price: <number> per person\nRETURN | Flight Number: <id> | from <OriginCity> to <DestCity> | Departure Time: <HH:MM> | Arrival Time: <HH:MM> | Price: <number> per person";

const stayFoodPrompt = TRIP + "\nYou are the LODGING + DINING scout for Palm Springs. " + HARD_RULES + "\n\nCalls to make:\n1. mcp__travelplanner__search_accommodations city \"Palm Springs\"\n2. mcp__travelplanner__search_restaurants city \"Palm Springs\"\n\nWe need 2 nights (2022-03-27 and 2022-03-28) for 1 person, so only report accommodations whose minimum nights is 2 or less and whose maximum occupancy is at least 1.\n\nReport up to 6 accommodations, cheapest first, one per line:\nSTAY | <NAME exactly as returned> | price per night: <number> | room type: <type> | minimum nights: <n> | max occupancy: <n>\n\nThen up to 9 restaurants, one per line, mixing cheap and mid-priced:\nFOOD | <Name exactly as returned> | average cost: <number> | cuisines: <list> | city: Palm Springs";

const attractionPrompt = TRIP + "\nYou are the ATTRACTION scout for Palm Springs. " + HARD_RULES + "\n\nCalls to make:\n1. mcp__travelplanner__search_attractions city \"Palm Springs\"\n2. mcp__travelplanner__compute_distance origin \"Denver\", destination \"Palm Springs\", mode \"taxi\" (backup transport data only)\n\nReport up to 9 attractions, one per line:\nSEE | <Name exactly as returned> | city: Palm Springs\nThen one final line:\nBACKUP_DRIVE | <distance> | <duration> | <cost>";

const [flightRes, stayRes, seeRes] = await parallel([
  agent(flightPrompt, { model: "sonnet" }),
  agent(stayFoodPrompt, { model: "sonnet" }),
  agent(attractionPrompt, { model: "sonnet" })
]);

const plannerPrompt = TRIP + "\n\nYou are the ITINERARY PLANNER. Do NOT call any tools. Use only the scout data below.\n\n=== FLIGHT DATA ===\n" + asText(flightRes) + "\n\n=== LODGING + DINING DATA ===\n" + asText(stayRes) + "\n\n=== ATTRACTION DATA ===\n" + asText(seeRes) + "\n\nBuild the itinerary:\n- Day 1 (2022-03-27): fly Denver -> Palm Springs on the cheapest sensible outbound flight. current_city = \"from Denver to Palm Springs\". breakfast \"-\" if the flight is early, otherwise a Palm Springs restaurant. Include 1-2 attractions, lunch, dinner, accommodation.\n- Day 2 (2022-03-28): current_city = \"Palm Springs\", transportation \"-\", breakfast/lunch/dinner all Palm Springs restaurants, 2 attractions, SAME accommodation as day 1.\n- Day 3 (2022-03-29): fly Palm Springs -> Denver. current_city = \"from Palm Springs to Denver\". transportation = the return flight. accommodation \"-\". Meals only if they fit before departure time, else \"-\". Attractions \"-\", or one quick stop only if the return flight is afternoon or later.\n- Never reuse a restaurant or attraction anywhere in the trip.\n- The accommodation must allow a 2-night stay and be the same both nights.\n- Cost check (do the arithmetic): outbound flight + return flight + 2 nights accommodation + every meal (1 person) must be well under $2200. If not, swap to cheaper picks from the data.\n\nOutput ONLY one markdown json code block, nothing before or after it, in exactly this shape:\n\n{\n  \"idx\": 18,\n  \"query\": \"Could you design a 3-day travel itinerary from Denver to Palm Springs for 1 person? The travel should span from March 27th to March 29th, 2022. The travel budget is set at $2,200. No specific local constraints are given.\",\n  \"plan\": [\n    {\n      \"day\": 1,\n      \"current_city\": \"from Denver to Palm Springs\",\n      \"transportation\": \"Flight Number: F1234567, from Denver to Palm Springs, Departure Time: 09:00, Arrival Time: 11:00\",\n      \"breakfast\": \"-\",\n      \"attraction\": \"Attraction Name, Palm Springs;\",\n      \"lunch\": \"Restaurant Name, Palm Springs\",\n      \"dinner\": \"Restaurant Name, Palm Springs\",\n      \"accommodation\": \"Accommodation Name, Palm Springs\"\n    }\n  ]\n}\n\nField rules: transportation uses the exact \"Flight Number: <id>, from <A> to <B>, Departure Time: <HH:MM>, Arrival Time: <HH:MM>\" format or \"-\". Meals are \"<Name>, <City>\" or \"-\". attraction entries are \"<Name>, <City>;\" joined by semicolons, or \"-\". accommodation is \"<Name>, <City>\" or \"-\". Use real names from the scout data only.";

const plan = await agent(plannerPrompt, { model: "opus" });

return asText(plan);
