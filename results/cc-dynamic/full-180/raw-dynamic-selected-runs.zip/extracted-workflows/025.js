export const meta = {
  name: "ca-7day-idx110",
  description: "Plan a 7-day, 2-person Miami -> Los Angeles / Santa Barbara / San Francisco itinerary (Mar 8-14, 2022) under $7,200",
  phases: 2
};

const txt = (r) => {
  if (r == null) return "";
  if (typeof r === "string") return r;
  return r.result ?? r.text ?? r.output ?? r.report ?? JSON.stringify(r);
};

const RULES = `
Hard rules:
- Use ONLY the mcp__travelplanner__* tools. Make at most 4 tool calls total.
- If a search returns nothing, try ONE alternative and then stop. Never loop or retry.
- Do NOT invent data. Copy names verbatim, including punctuation.
- Be compact: no prose analysis, just the structured listing requested.
`;

const cityTask = (city, nights, checkin, checkout) => () => agent(
`You are gathering on-the-ground data in ${city}, California for a TravelPlanner itinerary.

Trip: 2 travelers, ${nights} night(s) in ${city} (check in ${checkin}, check out ${checkout}). Cuisine preference: Mexican and American.

Do exactly this (3 tool calls, no more):
1. mcp__travelplanner__search_accommodations(city="${city}")
2. mcp__travelplanner__search_restaurants(city="${city}")
3. mcp__travelplanner__search_attractions(city="${city}")

Then report under the heading "=== ${city} ===":
- ACCOMMODATIONS: the 5 cheapest options that satisfy BOTH: minimum nights <= ${nights} AND maximum occupancy >= 2. For each: exact NAME | price per night | room type | minimum nights | maximum occupancy | house rules.
- RESTAURANTS: 8 options, prioritizing Mexican and American cuisines, spread across price levels. For each: exact NAME | average cost | cuisines.
- ATTRACTIONS: 5 options. For each: exact NAME (verbatim) | city.
${RULES}`,
  { model: "sonnet", description: `${city} hotels, food, attractions` }
);

const [laRes, sbRes, sfRes] = await parallel([
  cityTask("Los Angeles", 2, "2022-03-08", "2022-03-10"),
  cityTask("Santa Barbara", 2, "2022-03-10", "2022-03-12"),
  cityTask("San Francisco", 2, "2022-03-12", "2022-03-14")
]);

const final = await agent(
`You are assembling the FINAL TravelPlanner answer. All data is already gathered; do NOT call any tools.

USER QUERY (verbatim):
"Can you help me create a 7-day travel itinerary for 2 people, starting from Miami, visiting 3 different cities in California from March 8th to March 14th, 2022? Our budget for the trip is $7,200. We enjoy Mexican and American cuisine."

=== VERIFIED TRANSPORT DATA (already fetched from the tools, use exactly these strings) ===
Outbound flight 2022-03-08, chosen (cheapest): Flight Number F3664909, Miami -> Los Angeles, Price 499 per person, DepTime 13:54, ArrTime 16:14
Return flight 2022-03-14, chosen (cheapest): Flight Number F3875295, San Francisco -> Miami, Price 577 per person, DepTime 08:23, ArrTime 16:43
Ground leg 2022-03-10: self-driving, from Los Angeles to Santa Barbara, duration: 1 hour 38 mins, distance: 153 km, cost: 7
Ground leg 2022-03-12: self-driving, from Santa Barbara to San Francisco, duration: 5 hours 8 mins, distance: 525 km, cost: 26

${txt(laRes)}

${txt(sbRes)}

${txt(sfRes)}

Build the 7-day plan for 2 travelers, 2022-03-08 to 2022-03-14, route Miami -> Los Angeles (2 nights) -> Santa Barbara (2 nights) -> San Francisco (2 nights) -> Miami:
- Day 1 (03-08): current_city "from Miami to Los Angeles". transportation = the outbound flight. breakfast "-", lunch "-", 1 attraction in Los Angeles, dinner in Los Angeles, accommodation in Los Angeles.
- Day 2 (03-09): current_city "Los Angeles". transportation "-". 3 meals + 2 attractions in Los Angeles, same LA accommodation.
- Day 3 (03-10): current_city "from Los Angeles to Santa Barbara". transportation = the LA->Santa Barbara self-driving string. breakfast in Los Angeles, lunch + dinner in Santa Barbara, 1 attraction in Santa Barbara, accommodation in Santa Barbara.
- Day 4 (03-11): current_city "Santa Barbara". transportation "-". 3 meals + 2 attractions in Santa Barbara, same SB accommodation.
- Day 5 (03-12): current_city "from Santa Barbara to San Francisco". transportation = the SB->San Francisco self-driving string. breakfast in Santa Barbara, lunch + dinner in San Francisco, 1 attraction in San Francisco, accommodation in San Francisco.
- Day 6 (03-13): current_city "San Francisco". transportation "-". 3 meals + 2 attractions in San Francisco, same SF accommodation.
- Day 7 (03-14): current_city "from San Francisco to Miami". transportation = the return flight. breakfast in San Francisco, lunch "-", dinner "-", attraction "-", accommodation "-".

Constraints:
- Same accommodation for both nights in each city; each must have minimum nights <= 2 and maximum occupancy >= 2.
- NEVER reuse a restaurant anywhere in the trip (all distinct). Never reuse an attraction.
- Favor Mexican and American cuisine restaurants.
- Copy every name verbatim from the gathered data. Meals/attractions must be in the city listed for that day.
- Keep the total (2 x $499 + 2 x $577 flights + $7 + $26 driving + 6 nights lodging x price + meals for 2) comfortably under $7,200. State the arithmetic in ONE short line BEFORE the JSON block.
- transportation formats exactly:
  Day 1: "Flight Number: F3664909, from Miami to Los Angeles, Departure Time: 13:54, Arrival Time: 16:14"
  Day 3: "self-driving, from Los Angeles to Santa Barbara, duration: 1 hour 38 mins, distance: 153 km, cost: 7"
  Day 5: "self-driving, from Santa Barbara to San Francisco, duration: 5 hours 8 mins, distance: 525 km, cost: 26"
  Day 7: "Flight Number: F3875295, from San Francisco to Miami, Departure Time: 08:23, Arrival Time: 16:43"

Output: one short budget line, then a single \`\`\`json code block containing exactly:
{"idx": 110, "query": "<the user query verbatim>", "plan": [ {day, current_city, transportation, breakfast, attraction, lunch, dinner, accommodation} x7 ]}
attraction entries are semicolon-separated "<Name>, <City>;" strings.`,
  { model: "opus", description: "Assemble final itinerary JSON" }
);

return txt(final);
