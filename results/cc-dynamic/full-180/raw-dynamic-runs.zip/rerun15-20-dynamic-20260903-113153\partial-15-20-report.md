# TravelPlanner selected-query evaluation

- Gateway base: `https://penguinapi.org`
- Model: `claude-opus-5`
- Selected: 5
- Delivered: 5/5 (100.00%)
- Commonsense micro: 40/40 (100.00%)
- Commonsense macro: 5/5 (100.00%)
- Hard micro: 5/5 (100.00%)
- Hard macro: 5/5 (100.00%)
- Final: 5/5 (100.00%)
- Cost: $8.3583

| idx | delivered | commonsense | hard | final | cost | error |
| ---: | :---: | :---: | :---: | :---: | ---: | --- |
| 15 | yes | pass | pass | pass | $1.9481 | - |
| 16 | yes | pass | pass | pass | $0.6556 | - |
| 17 | yes | pass | pass | pass | $1.9201 | - |
| 19 | yes | pass | pass | pass | $2.6199 | - |
| 20 | yes | pass | pass | pass | $1.2146 | - |
