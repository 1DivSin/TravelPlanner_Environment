export const meta = {
  name: "travelplanner-va-5day",
  description: "Gather Richmond and Norfolk data in parallel, then assemble a 5-day Washington->Virginia itinerary under $2,200",
  phases: 2
};

const cityPrompt = (city) => `You are gathering TravelPlanner database facts for ${city}, Virginia for a 5-day trip (1 traveler, 2 nights in this city, March 2022).

Make EXACTLY these 3 tool calls, once each, in one batch:
1. mcp__travelplanner__search_accommodations with city="${city}"
2. mcp__travelplanner__search_restaurants with city="${city}"
3. mcp__travelplanner__search_attractions with city="${city}"

Do NOT retry, do NOT call anything else, do NOT loop. If a call returns nothing, just say so and move on.

Then output a compact plain-text report (no preamble, no commentary):

ACCOMMODATIONS (${city}) - list the 4 cheapest rows that have "minimum nights" <= 2 AND "maximum occupancy" >= 1. For each: exact name | price per night | room type | minimum nights | maximum occupancy | house rules.

RESTAURANTS (${city}) - list 8 rows: exact name | average cost | cuisines.

ATTRACTIONS (${city}) - list 6 exact names.

Use the exact names as they appear in the tool output. Keep it under 40 lines.`;

const [richmond, norfolk] = await parallel([
  agent(cityPrompt("Richmond"), { model: "sonnet", description: "Gather Richmond data" }),
  agent(cityPrompt("Norfolk"), { model: "sonnet", description: "Gather Norfolk data" })
]);

const assemble = await agent(`Assemble a final 5-day TravelPlanner itinerary JSON. Do NOT call any tools - all data you need is below.

TRIP: 1 traveler, origin Washington, visit 2 cities in Virginia (Richmond then Norfolk), 2022-03-15 to 2022-03-19, total budget $2,200.

ROUTE (already verified via tools, use these exact strings):
- Day 1 (2022-03-15) Washington -> Richmond, cheapest flight: "Flight Number: F3926429, from Washington to Richmond, Departure Time: 18:18, Arrival Time: 19:03" (price $43)
- Day 3 (2022-03-17) Richmond -> Norfolk, no flights available, taxi: "taxi, from Richmond to Norfolk, duration: 1 hour 34 mins, distance: 150 km, cost: 150" (cost $150)
- Day 5 (2022-03-19) Norfolk -> Washington, flight: "Flight Number: F3792580, from Norfolk to Washington, Departure Time: 15:49, Arrival Time: 16:43" (price $30)

Stay: nights of Mar 15 and Mar 16 in Richmond; nights of Mar 17 and Mar 18 in Norfolk. Day 5 accommodation is "-".

RICHMOND DATA:
${richmond}

NORFOLK DATA:
${norfolk}

RULES:
- current_city: day 1 = "from Washington to Richmond"; day 2 = "Richmond"; day 3 = "from Richmond to Norfolk"; day 4 = "Norfolk"; day 5 = "from Norfolk to Washington".
- Day 1 breakfast and lunch are "-" (evening arrival). Day 1 dinner in Richmond. Day 5 dinner is "-" (afternoon departure); day 5 breakfast and lunch in Norfolk.
- Never reuse the same restaurant twice anywhere in the plan. Never reuse the same attraction twice.
- Meals and attractions must be located in the city listed for that day. On day 3 (Richmond -> Norfolk taxi) put breakfast in Richmond and lunch/dinner in Norfolk; attractions on day 3 in Norfolk.
- Each day (except day 5) should have 1-2 attractions from the correct city. Day 5 can have 1 Norfolk attraction or "-".
- Pick the cheapest valid accommodation per city (minimum nights <= 2).
- Budget check: sum transportation ($223) + accommodation (2 nights x Richmond nightly + 2 nights x Norfolk nightly) + all listed meals (average cost each) + attractions ($0). It MUST total under $2,200. If over, pick cheaper options.

OUTPUT: first a one-line budget total like "TOTAL: $NNN", then the JSON object in a \`\`\`json code block with this exact shape and field order:
{"idx": 28, "query": "Could you create a 5-day travel plan for me, beginning in Washington, visiting 2 cities in Virginia from March 15th to March 19th, 2022? I have a budget of $2,200 for this trip.", "plan": [{"day": 1, "current_city": "...", "transportation": "...", "breakfast": "...", "attraction": "...", "lunch": "...", "dinner": "...", "accommodation": "..."}, ... 5 entries ...]}

attraction field format: "Name, City;Another Name, City;" (semicolon after each, including the last). Meals/accommodation: "Name, City". No other output.`, { model: "opus", description: "Assemble itinerary JSON" });

return assemble;
