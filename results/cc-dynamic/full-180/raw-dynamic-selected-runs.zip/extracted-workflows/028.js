export const meta = {
  name: "travelplanner-idx116",
  description: "Scout party-friendly stays, restaurants and attractions for Los Angeles, Santa Ana and San Diego",
  phases: 1
};

const cities = [
  { name: "Los Angeles", nights: 2 },
  { name: "Santa Ana", nights: 2 },
  { name: "San Diego", nights: 2 }
];

const mkPrompt = (c) => `Gather TravelPlanner data for ${c.name}, California. Group of 5 travelers, ${c.nights} nights there, trip runs 2022-03-22 to 2022-03-28.

Make EXACTLY these three tool calls and nothing else (issue them in a single parallel batch):
1. mcp__travelplanner__search_accommodations with city="${c.name}"
2. mcp__travelplanner__search_restaurants with city="${c.name}"
3. mcp__travelplanner__search_attractions with city="${c.name}"

Never retry a call and never call any other tool. If a call returns nothing, just say so.

Then answer in compact plain text (under 400 words), using names copied VERBATIM from tool output:

ACCOMMODATION: 2 best options that satisfy ALL of: house rules do NOT forbid parties (must not contain "No parties"), maximum occupancy >= 5, minimum nights <= ${c.nights}. For each give: exact name | price per night | room type | maximum occupancy | minimum nights | house rules. If nothing qualifies, write NONE and then list the 2 closest options with the same fields.

RESTAURANTS: 6 distinct exact names, each with average cost.

ATTRACTIONS: 6 distinct exact names.`;

const results = await parallel(
  cities.map((c) =>
    agent(mkPrompt(c), {
      name: `scout-${c.name.toLowerCase().replace(/\s+/g, "-")}`,
      model: "sonnet"
    })
  )
);

return results;
