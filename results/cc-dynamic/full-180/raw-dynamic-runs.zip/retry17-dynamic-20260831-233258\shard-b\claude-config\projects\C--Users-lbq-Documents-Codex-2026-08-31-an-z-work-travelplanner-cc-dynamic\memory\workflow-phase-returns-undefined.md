---
name: workflow-phase-returns-undefined
description: "In Workflow scripts, phase() does not forward its callback's return value — destructuring its result throws"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c0afe94a-8eab-4b57-8883-2ca270542585
  modified: 2026-08-31T15:42:01.667Z
---

In Workflow tool scripts, `await phase(n, "title", () => parallel([...]))` resolves to `undefined`, so `const [a, b] = await phase(...)` fails with `undefined is not an object`. Call `parallel()` / `agent()` directly and let sequential `await`s define the phases instead.

**Why:** a TravelPlanner run died in 27ms with `Error: undefined is not an object (evaluating '[orlando, miami]')` before any agent started, which reads like a script syntax problem rather than an API contract one.

**How to apply:** use `const [a, b] = await parallel([() => agent(A), () => agent(B)]); const out = await agent(C)`. Keep [[workflow-parallel-needs-thunks]] in mind at the same time — `parallel()` still needs thunks. Iterate by editing the persisted script file and re-invoking with `scriptPath`.
