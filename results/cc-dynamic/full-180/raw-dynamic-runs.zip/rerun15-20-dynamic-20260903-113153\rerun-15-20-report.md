# TravelPlanner selected-query evaluation

- Gateway base: `https://penguinapi.org`
- Model: `claude-opus-5`
- Selected: 6
- Delivered: 6/6 (100.00%)
- Commonsense micro: 48/48 (100.00%)
- Commonsense macro: 6/6 (100.00%)
- Hard micro: 5/6 (83.33%)
- Hard macro: 5/6 (83.33%)
- Final: 5/6 (83.33%)
- Cost: $9.5677

| idx | delivered | commonsense | hard | final | cost | error |
| ---: | :---: | :---: | :---: | :---: | ---: | --- |
| 15 | yes | pass | pass | pass | $1.9481 | - |
| 16 | yes | pass | pass | pass | $0.6556 | - |
| 17 | yes | pass | pass | pass | $1.9201 | - |
| 18 | yes | pass | fail | fail | $1.2094 | - |
| 19 | yes | pass | pass | pass | $2.6199 | - |
| 20 | yes | pass | pass | pass | $1.2146 | - |
