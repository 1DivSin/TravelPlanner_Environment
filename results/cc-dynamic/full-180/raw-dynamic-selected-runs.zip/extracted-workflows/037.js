export const meta = {
  name: "ga-3city-itinerary-v2",
  description: "Plan a 7-day Chattanooga -> 3 Georgia cities road-trip itinerary (Mar 9-15, 2022, 2 people, $6900).",
  phases: ["city-research", "synthesis"],
};

const ROUTE = `
Fixed route (already computed by the orchestrator, do NOT recompute):
- Day 1 (2022-03-09): self-driving, from Chattanooga to Atlanta, duration: 1 hour 48 mins, distance: 190 km, cost: 9
- Days 1-3: Atlanta (2 nights: Mar 9, Mar 10)
- Day 3 (2022-03-11): self-driving, from Atlanta to Decatur, duration: 18 mins, distance: 10.0 km, cost: 0
- Days 3-5: Decatur (2 nights: Mar 11, Mar 12)
- Day 5 (2022-03-13): self-driving, from Decatur to Augusta, duration: 2 hours 17 mins, distance: 228 km, cost: 11
- Days 5-7: Augusta (2 nights: Mar 13, Mar 14)
- Day 7 (2022-03-15): self-driving, from Augusta to Chattanooga, duration: 3 hours 58 mins, distance: 424 km, cost: 21
No air travel. Budget $6900 total for 2 travelers.
`;

function txt(r) {
  if (r == null) return "(no data)";
  if (typeof r === "string") return r;
  return r.text ?? r.result ?? r.output ?? r.content ?? JSON.stringify(r);
}

function cityPrompt(city, nights) {
  return `You are researching the city of ${city}, Georgia for a TravelPlanner itinerary.
${ROUTE}
The travelers stay ${nights} nights in ${city}.

Make AT MOST 3 tool calls, in this order:
1. mcp__travelplanner__search_accommodations for "${city}"
2. mcp__travelplanner__search_restaurants for "${city}"
3. mcp__travelplanner__search_attractions for "${city}"
If a tool returns nothing, do not retry it more than once; move on.

Accommodation hard constraints (must all hold):
- room type is "Private room" (NOT "Entire home/apt", NOT "Shared room")
- house rules must NOT include "No visitors"
- minimum nights <= ${nights}
- maximum occupancy >= 2
Pick the cheapest qualifying option (price is per night for the whole unit).

Then report back in COMPACT plain text, no preamble:
ACCOMMODATION: <exact name> | price/night $<n> | room type | min nights <n> | max occupancy <n> | house rules: <rules>
RESTAURANTS (list exactly 6 distinct real names from the tool output, with average cost):
1. <exact name> | avg cost $<n>
... through 6
ATTRACTIONS (list exactly 4 distinct real names from the tool output):
1. <exact name>
... through 4
Use ONLY names that literally appear in the tool results. Do not invent anything.`;
}

let atl = "(no data)";
let dec = "(no data)";
let aug = "(no data)";

await phase("city-research", async () => {
  const res = await parallel([
    agent(cityPrompt("Atlanta", 2), { name: "atlanta", model: "sonnet" }),
    agent(cityPrompt("Decatur", 2), { name: "decatur", model: "sonnet" }),
    agent(cityPrompt("Augusta", 2), { name: "augusta", model: "sonnet" }),
  ]);
  const arr = Array.isArray(res) ? res : [res];
  atl = txt(arr[0]);
  dec = txt(arr[1]);
  aug = txt(arr[2]);
  return arr.length;
});

let final = "";

await phase("synthesis", async () => {
  const out = await agent(
    `Assemble the final TravelPlanner JSON itinerary. Make NO tool calls at all — use only the data below.
${ROUTE}

ATLANTA RESEARCH:
${atl}

DECATUR RESEARCH:
${dec}

AUGUSTA RESEARCH:
${aug}

Output rules:
- 7 day objects, day 1..7.
- current_city: day 1 = "from Chattanooga to Atlanta"; day 2 = "Atlanta"; day 3 = "from Atlanta to Decatur"; day 4 = "Decatur"; day 5 = "from Decatur to Augusta"; day 6 = "Augusta"; day 7 = "from Augusta to Chattanooga".
- transportation: on days 1,3,5,7 use the exact self-driving string from the route above, capitalized as "Self-driving, from X to Y, duration: ..., distance: ..., cost: ...". Days 2,4,6 = "-".
- accommodation: the chosen private room for the city they SLEEP in that night. Days 1,2 = Atlanta stay; days 3,4 = Decatur stay; days 5,6 = Augusta stay; day 7 = "-" (they drive home).
- breakfast/lunch/dinner: "<Restaurant Name>, <City>". Day 1 breakfast = "-" (departure day). Day 7 dinner = "-" (driving home). Every other meal must be filled.
- NEVER reuse the same restaurant name anywhere in the whole plan. Each city has 6 restaurants; use each city's restaurants only for meals eaten in that city. On a travel day, meals may come from either the origin or destination city of that day — label with the correct city.
- attraction: 1-2 entries per day formatted "<Name>, <City>;" joined by ";". Attractions must be in the city they are in that day. Never reuse an attraction. Day 7 may be "-"; prefer at least one attraction on day 1.
- Keep total cost well under $6900 for 2 people.

Return ONLY the JSON object in a single \`\`\`json code block, with keys "idx" (163), "query" (verbatim below), "plan".
query verbatim: "We're seeking a 7-day travel plan for two persons, starting from Chattanooga and covering three different cities in Georgia. The travel dates are set between March 9th to March 15th, 2022. Our new budget is $6,900. We require accommodations that are neither shared nor subject to visitor restrictions and should be private rooms. For transportation, we'd rather avoid air travel."`,
    { name: "synthesizer", model: "sonnet" }
  );
  final = txt(out);
  return final.length;
});

return final;
