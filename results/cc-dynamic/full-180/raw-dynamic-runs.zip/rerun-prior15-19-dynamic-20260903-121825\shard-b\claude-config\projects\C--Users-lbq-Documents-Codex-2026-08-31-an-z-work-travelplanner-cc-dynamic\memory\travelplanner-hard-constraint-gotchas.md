---
name: travelplanner-hard-constraint-gotchas
description: "The four TravelPlanner scorer rules that silently fail plans — minimum nights, occupancy-scaled lodging cost, trailing ';' on attractions, and last-day accommodation."
metadata: 
  node_type: memory
  type: reference
  originSessionId: fef73dbc-685f-48fd-9c3f-336bc619b5d4
  modified: 2026-09-03T05:15:45.799Z
---

TravelPlanner scoring details found in `TravelPlanner/evaluation/{commonsense,hard}_constraint.py`:

1. `is_valid_accommodaton` counts *consecutive* identical accommodation strings and fails if that count `<` the listing's `minimum nights`. A 2-night stay needs `minimum nights <= 2`.
2. Lodging cost is `price * ceil(people / maximum occupancy)` per night; meals and flights are `* people`; self-driving is `cost * ceil(people/5)`, taxi `* ceil(people/4)`.
3. `is_valid_attractions` does `attraction.split(';')[:-1]`, so every attraction entry MUST end with a trailing `;` or it is dropped from validation and from the plan's content.
4. `is_not_absent` requires accommodation on every day except the last, requires an attraction on any day whose `current_city` has no `from `, and requires all three meals on non-travel days.

5. Many rows have an EMPTY `house_rules` field, which trivially satisfies any "allow X" house-rule query. Research subagents routinely skip these rows and report "only N qualify", which inflates lodging cost (2026-09-03: a San Diego agent reported 2 qualifying rows at $847+ and missed `Large room with private bath & kitchen near train` at $239 with blank rules).

**Why:** each of these fails a plan that otherwise looks complete, and none of them are visible in the tool output.

**How to apply:** when composing a plan, filter lodging by `minimum nights <= nights_planned` and by the query's house rule before costing it. See `[[workflow-tool-works-here]]`.
