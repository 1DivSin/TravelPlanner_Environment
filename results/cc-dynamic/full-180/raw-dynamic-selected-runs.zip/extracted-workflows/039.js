export const meta = {
  name: "wisconsin-5day-itinerary",
  description: "Research accommodations, dining, attractions and driving legs for a 5-day no-flight Charlotte -> Wisconsin itinerary for 2 travelers under $2500",
  phases: 2
};

const cityPrompt = (city) => `You are gathering raw options for a TravelPlanner itinerary in ${city}, Wisconsin. Trip: 2 travelers plus children under 10, March 18-22 2022, total budget $2500, no flights.

Use the travelplanner MCP tools. Make AT MOST 3 tool calls, in this order:
1. search_accommodations with city="${city}"
2. search_restaurants with city="${city}"
3. search_attractions with city="${city}"

Never retry a call and never loop. If one returns nothing, skip it and continue.

Then report ONLY this, using names copied VERBATIM from the tool output:

CITY: ${city}
ACCOMMODATIONS - keep only rows whose room type is "Private room" AND whose house rules do NOT contain "No children under 10". List the 4 cheapest as: NAME | price per night | minimum nights | maximum occupancy | room type | house rules
RESTAURANTS - list 8 as: NAME | average cost
ATTRACTIONS - list 6 as: NAME

No commentary, no analysis.`;

await phase("city-research", async () => parallel([
  agent(cityPrompt("Milwaukee"), { description: "Research Milwaukee options" }),
  agent(cityPrompt("Madison"), { description: "Research Madison options" })
]));

await phase("driving-legs", async () => agent(`Compute the driving legs for a no-flight trip. Use the travelplanner compute_distance tool with mode="driving". Make EXACTLY these 3 calls:
1. origin="Charlotte", destination="Milwaukee"
2. origin="Milwaukee", destination="Madison"
3. origin="Madison", destination="Charlotte"

Never retry. Report the three result strings VERBATIM, one per line, nothing else.`, { description: "Compute driving legs" }));
