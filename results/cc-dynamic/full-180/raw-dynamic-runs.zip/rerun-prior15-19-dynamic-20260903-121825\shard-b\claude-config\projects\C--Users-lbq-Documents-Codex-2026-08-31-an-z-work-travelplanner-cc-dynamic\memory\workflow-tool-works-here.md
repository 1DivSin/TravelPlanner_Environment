---
name: workflow-tool-works-here
description: In travelplanner-cc-dynamic the Workflow tool DOES run agents (verified 2026-09-03); check journal.jsonl rather than assuming a no-op.
metadata: 
  node_type: memory
  type: project
  originSessionId: fef73dbc-685f-48fd-9c3f-336bc619b5d4
  modified: 2026-09-03T04:41:28.822Z
---

In `travelplanner-cc-dynamic`, a `Workflow` call with `meta` + sequential `await agent(...)` + `parallel([() => agent(...)])` ran 4 real subagents and wrote `journal.jsonl` plus per-agent `.jsonl` transcripts under `<transcript dir>/subagents/workflows/<runId>/`. This corrects the earlier note that Workflow always returns `agentCount: 0`.

**Why:** treating Workflow as broken wastes the requested orchestration and duplicates all the work inline.

**How to apply:** launch the workflow as asked, then check `journal.jsonl` in the transcript dir to confirm agents ran. Still verify the workflow's final JSON against the sandbox CSVs — the 2026-09-03 run invented two Grand Rapids restaurants and picked a Traverse City rental whose `minimum nights` (3) exceeded the 2 nights planned. Keep `[[travelplanner-hard-constraint-gotchas]]` in mind.
