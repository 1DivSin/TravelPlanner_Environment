export const meta = {
  name: "tp-113-michigan-scout",
  description: "Scout child-friendly accommodations, restaurants and attractions for 3 Michigan cities for TravelPlanner query 113.",
  phases: 1,
};

const cities = ["Detroit", "Lansing", "Grand Rapids"];

const promptFor = (city) => `You are scouting the Michigan city of ${city} for a 7-day TravelPlanner itinerary (party of 5 people, March 6-12 2022, accommodations MUST be suitable for children under 10, and each stay is only 2 nights).

Make EXACTLY these 3 tool calls, in this order, and nothing else:
1. mcp__travelplanner__search_accommodations with city="${city}"
2. mcp__travelplanner__search_restaurants with city="${city}"
3. mcp__travelplanner__search_attractions with city="${city}"

If a call returns no results, do NOT retry it and do NOT try alternatives. Just move on.

Then reply with ONLY a compact report in this exact plain-text shape (no preamble, no explanation, no markdown fences):

ACCOMMODATIONS
List up to 5 rows. Include ONLY rows that satisfy BOTH: (a) house_rules do NOT contain "No children under 10", and (b) "minimum nights" <= 2. Sort cheapest effective cost first, where effective_cost = price * ceil(5 / maximum_occupancy). Format:
NAME | price | room type | house_rules | minimum nights | maximum occupancy | effective_cost

RESTAURANTS
Exactly 8 rows, preferring low "Average Cost" and varied cuisines. Format:
NAME | Average Cost | Cuisines

ATTRACTIONS
Exactly 6 rows. Format:
NAME

Copy every NAME verbatim from the tool output, character for character, including punctuation, capitalisation and any trailing words. Do not invent, translate, shorten or reformat any name. If a section had no usable rows, write the single word NONE under that heading.`;

await parallel(
  cities.map((city) => ({
    prompt: promptFor(city),
    opts: { subagent_type: "general-purpose", description: `Scout ${city}` },
  }))
);
