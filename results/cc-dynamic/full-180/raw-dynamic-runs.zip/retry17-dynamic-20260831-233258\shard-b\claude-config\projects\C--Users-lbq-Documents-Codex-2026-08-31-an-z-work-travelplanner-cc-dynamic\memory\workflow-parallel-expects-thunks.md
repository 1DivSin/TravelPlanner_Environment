---
name: workflow-parallel-expects-thunks
description: "Workflow parallel() needs an array of zero-arg functions, not already-invoked agent() promises."
metadata: 
  node_type: memory
  type: project
  originSessionId: ca4951e9-8a1a-456b-ac89-717f3166d8fc
  modified: 2026-08-31T16:20:56.635Z
---

In Workflow scripts, `parallel([...])` throws `TypeError: parallel() expects an array of functions, not promises` if you pass `agent(...)` calls directly. Wrap each one: `parallel([() => agent(a), () => agent(b)])`. Results come back as an array in the same order.

**Why:** Failed a run on 2026-09-01 in travelplanner-cc-dynamic; the workflow died in 95ms before any agent started.

**How to apply:** Always write `() => agent(...)` inside `parallel()`. See also [[workflow-phase-returns-undefined]].
