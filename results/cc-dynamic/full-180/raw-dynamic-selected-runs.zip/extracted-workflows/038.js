export const meta = {
  name: "ga-3city-data-v3",
  description: "Gather Georgia lodging/dining/attraction options for a 7-day no-flight Chattanooga road trip",
  phases: 1
};

const cityPrompt = (city) => `Gather raw options for a TravelPlanner itinerary in ${city}, Georgia. Trip: 2 adults, March 9-15 2022, no flights, budget $6900.

Use the travelplanner MCP tools. Make AT MOST 3 tool calls, in this order:
1. search_accommodations with city="${city}"
2. search_restaurants with city="${city}"
3. search_attractions with city="${city}"

Never retry a call and never loop. If one returns nothing, skip it and continue.

Then report ONLY this, using names copied VERBATIM from the tool output:

CITY: ${city}
ACCOMMODATIONS - keep only rows whose room type is exactly "Private room" AND whose house rules do NOT contain "No visitors" AND minimum nights <= 2 AND maximum occupancy >= 2. List the 4 cheapest as: NAME | price | minimum nights | maximum occupancy | room type | house rules
RESTAURANTS - list 8 as: NAME | average cost
ATTRACTIONS - list 6 as: NAME

No commentary, no analysis.`;

const cityResults = await parallel([
  () => agent(cityPrompt("Atlanta"), { description: "Research Atlanta options" }),
  () => agent(cityPrompt("Decatur"), { description: "Research Decatur options" }),
  () => agent(cityPrompt("Augusta"), { description: "Research Augusta options" })
]);

return JSON.stringify({ cities: cityResults }, null, 2);
