export const meta = {
  name: "travelplanner-sf-3day-idx19",
  description: "Plan a 3-day Seattle to San Francisco itinerary (Mar 21-23, 2022) for 1 person under a $900 budget",
  phases: 2
};

const txt = (r) => {
  if (r == null) return "";
  if (typeof r === "string") return r;
  return r.result ?? r.text ?? r.output ?? r.report ?? JSON.stringify(r);
};

const RULES = `
Hard rules:
- Use ONLY the mcp__travelplanner__* tools. Make at most 5 tool calls total.
- If a search returns nothing, try ONE alternative spelling and then stop. Never loop or retry repeatedly.
- Do NOT invent data. Report only what the tools actually returned, copied verbatim.
- Be compact: no prose analysis, just the structured listing requested.
`;

const [flightRes, localRes] = await parallel([
  () => agent(`You are gathering flight data for a TravelPlanner itinerary.

Trip: 1 traveler, origin city "Seattle", destination city "San Francisco", 3-day trip 2022-03-21 to 2022-03-23.

Do exactly this:
1. mcp__travelplanner__search_flights(origin="Seattle", destination="San Francisco", departure_date="2022-03-21")
2. mcp__travelplanner__search_flights(origin="San Francisco", destination="Seattle", departure_date="2022-03-23")
3. If either search returns no rows, call mcp__travelplanner__compute_distance for that leg (mode="taxi") as the fallback.

Then report:
- OUTBOUND 2022-03-21: the 5 cheapest flights, each as: Flight Number | price | DepTime | ArrTime | actual OriginCity -> DestCity strings exactly as returned.
- RETURN 2022-03-23: same, 5 cheapest.
- If you used compute_distance, report distance/duration/cost verbatim.
${RULES}`, { model: "sonnet", description: "Flights Seattle<->San Francisco" }),

  () => agent(`You are gathering on-the-ground data in San Francisco for a TravelPlanner itinerary.

Trip: 1 traveler, San Francisco, 2 nights (check in 2022-03-21, check out 2022-03-23), TIGHT total trip budget $900 including flights.

Do exactly this (3 tool calls, no more):
1. mcp__travelplanner__search_accommodations(city="San Francisco")
2. mcp__travelplanner__search_restaurants(city="San Francisco")
3. mcp__travelplanner__search_attractions(city="San Francisco")

Then report:
- ACCOMMODATIONS: the 6 CHEAPEST options whose "minimum nights" is <= 2 and whose maximum occupancy is >= 1. For each: exact NAME | price per night | room type | minimum nights | maximum occupancy | house rules.
- RESTAURANTS: 9 CHEAP options (lowest average cost). For each: exact NAME | average cost | cuisines.
- ATTRACTIONS: 6 options. For each: exact NAME (verbatim, including punctuation) | city.
${RULES}`, { model: "sonnet", description: "San Francisco hotels, food, attractions" })
]);

const final = await agent(`You are assembling the FINAL TravelPlanner answer. All data is already gathered; do NOT call any tools.

USER QUERY:
"Could you assist in creating a travel plan for one person departing from Seattle and visiting San Francisco for 3 days, from March 21st to March 23rd, 2022? The new budget is $900."

=== FLIGHT DATA ===
${txt(flightRes)}

=== SAN FRANCISCO DATA ===
${txt(localRes)}

Build a 3-day plan for 1 traveler, 2022-03-21 to 2022-03-23:
- Day 1: fly Seattle -> San Francisco (cheapest reasonable outbound). current_city = "from Seattle to San Francisco". breakfast "-", then attraction(s), lunch, dinner, accommodation.
- Day 2: current_city = "San Francisco". All three meals, 2 attractions, same accommodation.
- Day 3: fly San Francisco -> Seattle. current_city = "from San Francisco to Seattle". breakfast and lunch in San Francisco, dinner "-", accommodation "-", 1 attraction or "-".
- Use the SAME accommodation both nights, and it must have minimum nights <= 2.
- Never reuse the same restaurant twice across the whole trip.
- Copy names verbatim from the data. Every meal/attraction/hotel city is "San Francisco".
- BUDGET IS TIGHT ($900 for 1 person): pick the cheapest flights and the cheapest qualifying accommodation. Keep total cost (2 flights + 2 nights lodging + meals) under $900 and state the arithmetic in ONE short line BEFORE the JSON block.
- transportation format exactly: "Flight Number: <num>, from Seattle to San Francisco, Departure Time: <HH:MM>, Arrival Time: <HH:MM>" (and the reverse on day 3).

Output: one short budget line, then a single \`\`\`json code block containing exactly:
{"idx": 19, "query": "<the user query verbatim>", "plan": [ {day, current_city, transportation, breakfast, attraction, lunch, dinner, accommodation} x3 ]}
attraction entries are semicolon-separated "<Name>, San Francisco;" strings.`, { model: "opus", description: "Assemble final itinerary JSON" });

return txt(final);
