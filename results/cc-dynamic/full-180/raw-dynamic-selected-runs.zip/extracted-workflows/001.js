export const meta = {
  name: "travelplanner-sf-3day",
  description: "Plan a 3-day Spokane -> San Francisco itinerary (Mar 3-5 2022, 1 person, $1200 budget)",
  phases: ["research", "compose", "validate"]
};

const common = `TravelPlanner task context: a 3-day trip for 1 traveler from Spokane to San Francisco, March 3-5 2022 (arrive Mar 3, depart back Mar 5), total budget USD 1200 covering flights + 2 nights lodging + meals.

Use the travelplanner MCP tools (search_flights, search_accommodations, search_restaurants, search_attractions, compute_distance).
HARD LIMIT: at most 5 tool calls. If a search returns nothing, try ONE alternative and then stop. Do not loop or retry.
Report compact factual rows copied verbatim from the tool output. No commentary.`;

const research = await phase("research", () => parallel([
  agent(`${common}

YOUR TASK: FLIGHTS.
1. search_flights(origin="Spokane", destination="San Francisco", departure_date="2022-03-03")
2. search_flights(origin="San Francisco", destination="Spokane", departure_date="2022-03-05")
Report every returned row verbatim (Flight Number, Price, DepTime, ArrTime, FlightDate, OriginCityName, DestCityName).
Then recommend: cheapest outbound that still arrives early enough to sightsee on day 1, and cheapest return on Mar 5. Give the combined airfare total.`, { model: "sonnet" }),

  agent(`${common}

YOUR TASK: LODGING in San Francisco.
Call search_accommodations(city="San Francisco").
We need 2 nights (Mar 3 and Mar 4) for 1 person. Only options with "minimum nights" <= 2 and "maximum occupancy" >= 1 are valid.
Report the 8 cheapest VALID options: NAME, room type, price (per night), minimum nights, maximum occupancy, house_rules, and the computed 2-night total (price x 2).
Flag any house rule that would be a problem for a single traveler.`, { model: "sonnet" }),

  agent(`${common}

YOUR TASK: FOOD + SIGHTSEEING in San Francisco.
1. search_restaurants(city="San Francisco")
2. search_attractions(city="San Francisco")
Report ~12 restaurants: Name, Average Cost (per person per meal), Aggregate Rating, Cuisines. Include a spread of budget and mid-price options, and prefer rating >= 3.5.
Report ~8 notable attractions with Name and City spelled EXACTLY as the tool returns them.`, { model: "sonnet" })
]));

const composed = await phase("compose", () => agent(`You are composing the final TravelPlanner itinerary. Do NOT call any tools. Use only the research below.

RESEARCH - FLIGHTS:
${research[0]}

RESEARCH - LODGING:
${research[1]}

RESEARCH - FOOD AND ATTRACTIONS:
${research[2]}

Build a 3-day plan: 1 traveler, Spokane -> San Francisco, Mar 3-5 2022, total budget USD 1200.
Rules:
- Day 1 current_city = "from Spokane to San Francisco"; day 2 = "San Francisco"; day 3 = "from San Francisco to Spokane".
- Day 1 transportation = the chosen outbound flight, formatted EXACTLY: "Flight Number: F#######, from Spokane to San Francisco, Departure Time: HH:MM, Arrival Time: HH:MM". Day 2 transportation = "-". Day 3 = the return flight in the same format (from San Francisco to Spokane).
- Same accommodation both nights (days 1 and 2). Day 3 accommodation = "-".
- Day 1 breakfast = "-" (traveling). Every other meal slot gets a real San Francisco restaurant, no repeats anywhere in the plan. Meals on day 3 must fit before the return flight departs; if the return flight is early, set later meals to "-".
- Attractions: 1-2 per day on days 1-2, formatted "<Name>, San Francisco;" separated by semicolons. Day 3 may be "-" or one attraction if the return flight is late.
- Meals/lodging/restaurant names must be copied exactly from the research.
Compute a cost breakdown: airfare + (2 x nightly rate) + sum of all meal Average Costs. It MUST be under 1200; if not, swap to cheaper choices and recompute.

Output: first the cost breakdown with a total, then a single JSON object in a fenced code block with keys idx (16), query, and plan (array of 3 day objects with day, current_city, transportation, breakfast, attraction, lunch, dinner, accommodation).`, { model: "sonnet" }));

const validated = await phase("validate", () => agent(`You are validating a TravelPlanner plan. Do NOT call any tools.

CANDIDATE PLAN AND COSTS:
${composed}

SOURCE RESEARCH (the only allowed facts):
FLIGHTS:
${research[0]}
LODGING:
${research[1]}
FOOD/ATTRACTIONS:
${research[2]}

Check each item and fix any violation yourself:
1. Every flight number, restaurant name, hotel name and attraction name appears in the research above (no invented entries).
2. Flight strings match "Flight Number: F#######, from X to Y, Departure Time: HH:MM, Arrival Time: HH:MM".
3. current_city fields: day 1 "from Spokane to San Francisco", day 2 "San Francisco", day 3 "from San Francisco to Spokane".
4. Accommodation is the same for days 1-2, "-" on day 3, and its minimum nights <= 2 and maximum occupancy >= 1.
5. No restaurant repeats. Day 1 breakfast is "-". Day 3 meals fit before the return departure time.
6. Recomputed total (airfare + 2 nights lodging + all meals for 1 person) is under 1200.

Output the corrected cost total on one line, then ONLY the final JSON object in a fenced json code block, with exactly the keys idx, query, plan and the day fields day, current_city, transportation, breakfast, attraction, lunch, dinner, accommodation.`, { model: "sonnet" }));

return validated;
