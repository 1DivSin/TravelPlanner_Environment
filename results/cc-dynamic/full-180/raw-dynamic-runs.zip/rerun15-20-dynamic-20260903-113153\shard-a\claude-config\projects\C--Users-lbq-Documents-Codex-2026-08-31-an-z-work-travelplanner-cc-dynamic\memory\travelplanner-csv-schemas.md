---
name: travelplanner-csv-schemas
description: Column order and grep tips for the TravelPlanner database CSVs used when the MCP tools are unavailable.
metadata: 
  node_type: memory
  type: reference
  originSessionId: b037378a-f0b1-43d0-b0d6-4333a1a2a8ec
  modified: 2026-09-03T03:40:40.324Z
---

Under `TravelPlanner/database/` (needed when [[travelplanner-mcp-and-workflow-broken]] applies):

- `flights/clean_Flights_2022.csv` — `Flight Number,Price,DepTime,ArrTime,ActualElapsedTime,FlightDate,OriginCityName,DestCityName,Distance`. 300MB: always Grep, e.g. `,2022-03-29,St\. Louis,Las Vegas,`.
- `accommodations/clean_accommodations_2022.csv` — `,NAME,room type,price,minimum nights,review rate number,house_rules,maximum occupancy,city`. `price` is per night for the whole unit; city is last, so anchor with `,Las Vegas$`.
- `restaurants/clean_restaurant_2022.csv` — `,Name,City,Cuisines,Average Cost,Aggregate Rating`. City is a middle column: use `,Las Vegas,`. Cost is per person per meal.
- `attractions/attractions.csv` — `Name,Latitude,Longitude,Address,Phone,Website,City`. City is last: `,Las Vegas$`.
- `googleDistanceMatrix/distance.csv` — `origin,destination,cost,duration,distance`.

Note the city column is unreliable as a description: several `Las Vegas` accommodation rows carry NYC-flavored names. Filter on the column, not the name.
