export const meta = {
  name: "probe",
  description: "Minimal single-agent probe to check subagent spawning",
  phases: 1,
};

await phase("probe", () =>
  agent("Call mcp__travelplanner__search_attractions for city \"Erie\" exactly once, then reply with the first three attraction names, comma separated. Nothing else.", { model: "sonnet", description: "Probe" })
);
