export const meta = {
  name: "travelplanner-itinerary-17",
  description: "Verify and assemble a 3-day St. Louis -> Washington itinerary (idx 17) against the TravelPlanner CSV databases.",
  phases: ["verify-candidates", "validate-plan"],
};

const DB = "[SOURCE_ROOT]/an-z/work/travelplanner-cc-dynamic/TravelPlanner/database";

const TOOLING = `
IMPORTANT tooling constraints:
- The 'travelplanner' MCP server is NOT connected and Bash is DENIED in this session.
- Query the CSV databases directly with the Grep tool (output_mode "content").
- Make at most 5 tool calls. If a pattern returns nothing, try ONE alternative, then report what you found and stop. Do not loop.

Database files under ${DB}:
- flights/clean_Flights_2022.csv  cols: Flight Number,Price,DepTime,ArrTime,ActualElapsedTime,FlightDate,OriginCityName,DestCityName,Distance
- accommodations/clean_accommodations_2022.csv  cols: idx,NAME,room type,price,minimum nights,review rate number,house_rules,maximum occupancy,city
- restaurants/clean_restaurant_2022.csv  cols: idx,Name,City,Cuisines,Average Cost,Aggregate Rating
- attractions/attractions.csv  cols: Name,Latitude,Longitude,Address,Phone,Website,City
Anchor city matches with ',<City>$' or escape dots (St\\. Louis).
`;

const TRIP = `
Trip: 1 traveler, budget $1500, depart St. Louis 2022-03-01, return from Washington 2022-03-03. 3 days, 2 nights.
`;

const [travel, local] = await parallel([
  agent(
    `${TOOLING}${TRIP}
Verify the TRANSPORT + LODGING candidates below actually exist in the CSVs with these exact values.

Outbound flight: F3937820, $160, 08:21 -> 11:08, 2022-03-01, St. Louis -> Washington
Return flight:   F3788616, $146, 16:09 -> 17:42, 2022-03-03, Washington -> St. Louis
Accommodation:   "Stunning 2Bed/2BA + 300sqft deck by the river!", Washington, $209/night, minimum nights 1, maximum occupancy 3

Checks: (a) both flight rows exist verbatim; (b) they are the cheapest available on their date/route, or name the cheaper one; (c) the accommodation exists, minimum nights <= 2, and maximum occupancy >= 1.
Report: CONFIRMED or CORRECTED with the exact replacement row values, plus total transport+lodging cost (flights + 2 nights).`,
    { model: "sonnet", description: "Verify flights and lodging" }
  ),
  agent(
    `${TOOLING}${TRIP}
Verify these Washington RESTAURANT and ATTRACTION candidates exist in the CSVs, and that no restaurant is used twice.

Restaurants (Name, expected Average Cost): Moradabadi Biryani 12; The Hangar 74; Los Aztecas 46; Thaaliwala 88; Good Foods 65; Keventers 46; Manna Java World Cafe 59
Attractions: Space Needle; Chihuly Garden and Glass; Seattle Aquarium; The Gum Wall; Kerry Park; Olympic Sculpture Park

Checks: (a) each restaurant row exists with City == Washington and report its Average Cost; (b) each attraction exists with City == Washington; (c) flag any name containing non-ASCII/mojibake characters as unusable; (d) if any candidate is missing, propose ONE replacement from the same city.
Report a clean list of confirmed names plus the summed restaurant cost for 7 meals.`,
    { model: "sonnet", description: "Verify dining and attractions" }
  ),
]);

const validated = await agent(
  `${TOOLING}${TRIP}
Two verification agents reported on the candidate components.

TRANSPORT + LODGING REPORT:
${travel}

DINING + ATTRACTIONS REPORT:
${local}

Assemble the final 3-day plan and validate it. Rules:
- Day 1 current_city "from St. Louis to Washington"; Day 2 "Washington"; Day 3 "from Washington to St. Louis".
- transportation format exactly: "Flight Number: F3937820, from St. Louis to Washington, Departure Time: 08:21, Arrival Time: 11:08" (use the confirmed rows). "-" on Day 2.
- Day 1 breakfast "-" (08:21 departure). Day 3 accommodation "-" and dinner "-" (16:09 departure).
- Every restaurant used at most once across the whole trip. Meals/attractions must be in Washington.
- Accommodation is the same property on Day 1 and Day 2 (2 nights).
- Sum the total cost (flights + 2 nights lodging + all meals) and confirm it is <= $1500.

Report the final validated component assignments per day, the total cost, and any rule violation you had to fix. Do not emit JSON.`,
  { model: "sonnet", description: "Validate and assemble plan" }
);

return validated;
