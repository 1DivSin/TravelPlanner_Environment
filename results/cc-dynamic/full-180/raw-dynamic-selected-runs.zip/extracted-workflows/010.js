export const meta = {
  name: "tp-idx20-providence-orlando",
  description: "Plan a 3-day Providence -> Orlando trip for 1 traveler within a $1,800 budget",
  phases: 2,
};

const txt = (x) => (typeof x === "string" ? x : JSON.stringify(x));

const FLIGHTS_PROMPT = `You are gathering raw flight data for a TravelPlanner itinerary. Trip: 1 traveler, Providence -> Orlando, depart 2022-03-24, return 2022-03-26.

Make AT MOST 3 tool calls total. Start with exactly these two:
1. mcp__travelplanner__search_flights with origin="Providence", destination="Orlando", departure_date="2022-03-24"
2. mcp__travelplanner__search_flights with origin="Orlando", destination="Providence", departure_date="2022-03-26"

If EITHER returns no results, make ONE fallback call for that leg: mcp__travelplanner__compute_distance with the same origin/destination and mode="taxi", and report distance, duration, and cost. Do not retry a search that returned nothing. Do not loop.

Report a compact plain-text list (no commentary, no markdown tables):
OUTBOUND 2022-03-24: for the 6 cheapest options, one line each: "<Flight Number> | price <price> | dep <DepTime> | arr <ArrTime>"
RETURN 2022-03-26: same format, 6 cheapest.
If you used the distance fallback, print "FALLBACK <leg>: distance=..., duration=..., cost=...".
Copy field values EXACTLY as the tool returned them.`;

const LOCAL_PROMPT = `You are gathering raw local data for a TravelPlanner itinerary in Orlando. 1 traveler, 2 nights (2022-03-24 and 2022-03-25). No stated cuisine or room constraints.

Make EXACTLY these 3 tool calls, once each, then stop:
1. mcp__travelplanner__search_accommodations with city="Orlando"
2. mcp__travelplanner__search_restaurants with city="Orlando"
3. mcp__travelplanner__search_attractions with city="Orlando"

If one returns nothing, note "NONE" for it and move on. Do not retry.

Report compact plain text, values copied EXACTLY from the tools:
ACCOMMODATIONS: up to 10 lines, cheapest first: "<NAME> | price/night <price> | room type <type> | minimum nights <n> | maximum occupancy <n> | house rules <rules>"
RESTAURANTS: up to 16 lines, cheapest first: "<NAME> | avg cost <cost> | cuisines <cuisines>"
ATTRACTIONS: up to 10 lines: "<NAME>"
No commentary.`;

const [air, local] = await parallel([
  () => agent(FLIGHTS_PROMPT, { description: "Search flights both legs", model: "sonnet" }),
  () => agent(LOCAL_PROMPT, { description: "Search Orlando hotels/food/sights", model: "sonnet" }),
]);

const PLAN_PROMPT = `Assemble a budget-checked 3-day itinerary draft from the data below. DO NOT CALL ANY TOOLS. Pure reasoning + arithmetic only.

Trip: 1 traveler, depart Providence 2022-03-24, stay in Orlando, return to Providence 2022-03-26. Total budget $1,800. Only one city is visited (Orlando).

FLIGHT DATA:
${txt(air)}

ORLANDO DATA:
${txt(local)}

Rules you must respect:
- Cost model: flights = listed price x 1 per leg. Accommodation = price/night x 1 room x 2 nights. Restaurants = average cost x 1 per meal. Attractions are free.
- Accommodation must have "minimum nights" <= 2 and maximum occupancy >= 1.
- Pick DIFFERENT restaurants for every single meal slot across the whole trip (no repeats anywhere).
- Day 1 breakfast is "-" if the outbound flight is not an early morning flight; keep meals plausible relative to flight times (no dinner on day 1 if arrival is after ~22:00; no dinner on day 3 if the return flight departs before evening).
- Prefer an outbound flight that arrives early enough to allow at least one attraction on day 1; if the cheapest flight arrives late at night, prefer a moderately priced daytime flight since the budget is generous.
- Every restaurant/attraction/hotel must be in Orlando.
- 2 attractions on day 2, 1-2 attractions on days 1 and 3 only if flight times allow, else "-".

Output ONLY:
1. A COST TABLE listing each line item with its arithmetic and a TOTAL, and state whether TOTAL <= 1800.
2. The chosen outbound flight (number, dep, arr, price) and return flight (number, dep, arr, price), copied exactly.
3. The chosen accommodation (name, price/night, minimum nights, maximum occupancy).
4. Per-day assignments: day, breakfast, lunch, dinner, attractions, accommodation.
If the total exceeds 1800, swap to cheaper options and re-total before answering.`;

const plan = await agent(PLAN_PROMPT, { description: "Assemble budget-checked draft", model: "sonnet" });

return { flights: txt(air), orlando: txt(local), draft: txt(plan) };
