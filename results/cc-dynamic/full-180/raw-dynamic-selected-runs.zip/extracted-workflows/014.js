export const meta = {
  name: "va-3city-idx48",
  description: "Plan a 7-day Philadelphia-origin, 3-city Virginia itinerary (Mar 2-8 2022, $2900) with parallel city research",
  phases: ["logistics", "city-research", "assemble"]
};

const RULES = [
  "",
  "HARD LIMITS: make AT MOST 5 tool calls total, then answer immediately.",
  "If a call returns no rows, try ONE alternative and move on. Never repeat the same call.",
  "Do not use notebook tools. Do not read or write files. Answer in compact plain text, no preamble."
].join("\n");

const logisticsPrompt = [
  "You are gathering transportation data for a 1-traveler trip: Philadelphia -> Richmond VA -> Newport News VA -> Norfolk VA -> Philadelphia, March 2-8 2022.",
  "Make EXACTLY these 3 tool calls, once each:",
  "1. mcp__travelplanner__search_flights(origin=\"Norfolk\", destination=\"Philadelphia\", departure_date=\"2022-03-08\")",
  "2. mcp__travelplanner__compute_distance(origin=\"Richmond\", destination=\"Newport News\", mode=\"taxi\")",
  "3. mcp__travelplanner__compute_distance(origin=\"Newport News\", destination=\"Norfolk\", mode=\"taxi\")",
  "Then report:",
  "- RETURN FLIGHT: the cheapest Norfolk->Philadelphia flight on 2022-03-08 that departs at or after 10:00, as: Flight Number | Price | DepTime | ArrTime. Also list one backup row.",
  "- TAXI RICHMOND->NEWPORT NEWS: copy the tool's exact result string (duration, distance, cost).",
  "- TAXI NEWPORT NEWS->NORFOLK: copy the tool's exact result string (duration, distance, cost).",
  "Copy numbers and names exactly as printed.",
  RULES
].join("\n");

const legs = [
  { city: "Richmond", stay: "nights of Mar 2 and Mar 3 (days 1-2)" },
  { city: "Newport News", stay: "nights of Mar 4 and Mar 5 (days 3-4)" },
  { city: "Norfolk", stay: "nights of Mar 6 and Mar 7 (days 5-6)" }
];

const cityPrompt = (leg) => [
  "You are gathering TravelPlanner data for " + leg.city + ", Virginia, for a 1-traveler trip in March 2022.",
  "The traveler stays there for the " + leg.stay + " (2 consecutive nights).",
  "Make EXACTLY these 3 tool calls, once each:",
  "1. mcp__travelplanner__search_accommodations(city=\"" + leg.city + "\")",
  "2. mcp__travelplanner__search_restaurants(city=\"" + leg.city + "\")",
  "3. mcp__travelplanner__search_attractions(city=\"" + leg.city + "\")",
  "Report, copying names EXACTLY as printed (do not paraphrase, fix spelling, or change capitalization):",
  "- ACCOMMODATIONS: the 3 cheapest rows whose \"maximum occupancy\" >= 1 AND \"minimum nights\" <= 2, as: NAME | price | room type | minimum nights | maximum occupancy.",
  "- RESTAURANTS: 8 distinct restaurants as: NAME | Average Cost. Prefer a spread including several under $40.",
  "- ATTRACTIONS: 6 distinct attraction NAMES exactly as printed.",
  RULES
].join("\n");

const logistics = await phase("logistics", () => agent(logisticsPrompt, { model: "sonnet" }));

const findings = await phase("city-research", () =>
  parallel(legs.map((leg) => () => agent(cityPrompt(leg), { model: "sonnet" })))
);

const asText = (x) => {
  if (x == null) return "(no result)";
  if (typeof x === "string") return x;
  return x.result ?? x.text ?? x.output ?? JSON.stringify(x);
};

const arr = Array.isArray(findings) ? findings : [findings];

const assemblePrompt = [
  "Assemble the final TravelPlanner JSON itinerary. Do NOT call any tools. Use ONLY the data below.",
  "",
  "Query (idx 48): \"I require a travel itinerary for a seven-day trip beginning on March 2nd and ending on March 8th, 2022. The trip will begin in Philadelphia and involve visiting 3 cities in Virginia. The available budget for the trip is $2,900.\"",
  "1 traveler. Budget $2,900.",
  "",
  "FIXED outbound flight (copy verbatim into day 1 transportation):",
  "Flight Number: F3734535, from Philadelphia to Richmond, Departure Time: 09:40, Arrival Time: 10:51   (price $47)",
  "",
  "TRANSPORT RESEARCH (use for day 3, day 5, day 7 transportation strings):",
  asText(logistics),
  "",
  "CITY RESEARCH:",
  "--- RICHMOND (days 1-2) ---",
  asText(arr[0]),
  "",
  "--- NEWPORT NEWS (days 3-4) ---",
  asText(arr[1]),
  "",
  "--- NORFOLK (days 5-6) ---",
  asText(arr[2]),
  "",
  "STRUCTURE (exact current_city values):",
  "Day 1 \"from Philadelphia to Richmond\"; Day 2 \"Richmond\"; Day 3 \"from Richmond to Newport News\"; Day 4 \"Newport News\"; Day 5 \"from Newport News to Norfolk\"; Day 6 \"Norfolk\"; Day 7 \"from Norfolk to Philadelphia\".",
  "",
  "TRANSPORTATION field format:",
  "- Day 1: the fixed flight string above.",
  "- Day 3 and Day 5: taxi strings exactly in the form \"taxi, from A to B, duration: X, distance: Y km, cost: Z\" using the researched values.",
  "- Day 7: \"Flight Number: <num>, from Norfolk to Philadelphia, Departure Time: <dep>, Arrival Time: <arr>\" from the researched return flight.",
  "- Days 2, 4, 6: \"-\".",
  "",
  "ACCOMMODATION: cheapest qualifying Richmond hotel on days 1 and 2; Newport News hotel on days 3 and 4; Norfolk hotel on days 5 and 6; \"-\" on day 7. Format \"<Name>, <City>\". Reuse the same hotel name across its own consecutive nights.",
  "",
  "MEALS: every slot must be a real restaurant from the city you are physically in at that meal time, formatted \"<Name>, <City>\". NEVER reuse a restaurant name anywhere in the 7 days. Day 1 breakfast is \"-\" (morning flight); day 1 lunch and dinner in Richmond. Day 3 breakfast/lunch may be Richmond or Newport News, dinner Newport News. Day 5 breakfast/lunch may be Newport News or Norfolk, dinner Norfolk. Day 7 breakfast in Norfolk, then lunch and dinner \"-\" (midday flight home). Fill all other slots.",
  "",
  "ATTRACTIONS: 1-2 per day, formatted \"<Name>, <City>;\" with a trailing semicolon on each entry. Attractions must be in the city you are in that day. NEVER reuse an attraction. Day 7 attraction is \"-\".",
  "",
  "BUDGET CHECK: flights ~$47 + return + two taxis + 6 hotel nights + meals must stay under $2,900. Prefer mid-range, not rock-bottom, since the budget is generous, but never exceed it.",
  "",
  "OUTPUT: return ONLY a single ```json code block containing an object with keys idx (48), query (the exact query string above), and plan (array of 7 objects with keys day, current_city, transportation, breakfast, attraction, lunch, dinner, accommodation). No text outside the code block."
].join("\n");

const plan = await phase("assemble", () => agent(assemblePrompt, { model: "opus" }));

return plan;
