export const meta = {
  name: "va-3city-itinerary",
  description: "Research 3 Virginia cities in parallel, then assemble a 7-day Philadelphia-origin itinerary under $1,800",
  phases: ["research", "assemble"]
};

const legs = [
  { city: "Richmond", stay: "nights of Mar 15 and Mar 16 (2 nights, days 1-2)" },
  { city: "Newport News", stay: "nights of Mar 17 and Mar 18 (2 nights, days 3-4)" },
  { city: "Norfolk", stay: "nights of Mar 19 and Mar 20 (2 nights, days 5-6)" }
];

function researchPrompt(leg) {
  return [
    "You are researching " + leg.city + ", Virginia for a 1-traveler TravelPlanner itinerary (March 15-21, 2022, total trip budget $1,800).",
    "The traveler stays in " + leg.city + " for the " + leg.stay + ".",
    "",
    "Make EXACTLY these three MCP tool calls, once each, no retries:",
    "1. mcp__travelplanner__search_accommodations with city=\"" + leg.city + "\"",
    "2. mcp__travelplanner__search_restaurants with city=\"" + leg.city + "\"",
    "3. mcp__travelplanner__search_attractions with city=\"" + leg.city + "\"",
    "If a call returns nothing, say so and move on. Do not call any other tool.",
    "",
    "Then report, as compact plain text:",
    "- ACCOMMODATION: the single cheapest option whose minimum nights value is <= 2 and whose maximum occupancy is >= 1. Give exact NAME and price per night. If none qualify, say NONE and give the cheapest with minimum nights <= 2 you can find.",
    "- RESTAURANTS: 6 distinct restaurant NAMES with average cost, preferring average cost under $40. Exact names as returned.",
    "- ATTRACTIONS: 4 distinct attraction NAMES exactly as returned.",
    "Use exact names from the tool output, never invented ones. Keep the whole report under 250 words."
  ].join("\n");
}

const findings = await phase("research", async () =>
  parallel(legs.map((leg) => agent(researchPrompt(leg), { model: "sonnet" })))
);

const transport = [
  "Day 1 flight: \"Flight Number: F3730367, from Philadelphia to Richmond, Departure Time: 14:03, Arrival Time: 15:03\" (cost $73)",
  "Day 3 ground: \"taxi, from Richmond to Newport News, duration: 1 hour 5 mins, distance: 110 km, cost: 110\"",
  "Day 5 ground: \"taxi, from Newport News to Norfolk, duration: 37 mins, distance: 40.9 km, cost: 40\"",
  "Day 7 flight: \"Flight Number: F3732467, from Norfolk to Philadelphia, Departure Time: 11:31, Arrival Time: 12:38\" (cost $51)"
].join("\n");

const assemblePrompt = [
  "Assemble a final TravelPlanner JSON itinerary. Do NOT call any tools. Use only the data below.",
  "",
  "Query (idx 41): \"Can you help construct a travel plan that begins in Philadelphia and includes visits to 3 different cities in Virginia? The trip duration is for 7 days, from March 15th to March 21st, 2022, with a total budget of $1,800.\"",
  "",
  "Fixed transportation (copy these strings verbatim into the transportation field):",
  transport,
  "",
  "City research findings:",
  ...findings.map((f, i) => "--- " + legs[i].city + " ---\n" + f),
  "",
  "Structure: Day 1 current_city \"from Philadelphia to Richmond\"; Day 2 \"Richmond\"; Day 3 \"from Richmond to Newport News\"; Day 4 \"Newport News\"; Day 5 \"from Newport News to Norfolk\"; Day 6 \"Norfolk\"; Day 7 \"from Norfolk to Philadelphia\".",
  "Accommodation: chosen Richmond hotel on days 1-2, Newport News hotel days 3-4, Norfolk hotel days 5-6, \"-\" on day 7.",
  "Meals: day 1 breakfast \"-\" (mid-afternoon arrival); every other meal slot filled with a real restaurant from that day's city, formatted \"<Name>, <City>\". Never reuse a restaurant anywhere in the plan. On travel days pick restaurants matching the city you are actually in at that meal time.",
  "Attractions: 1-2 per day formatted \"<Name>, <City>;\" (trailing semicolon, semicolon-separated when two). Day 7 attraction \"-\" (morning flight). Never reuse an attraction.",
  "Budget: 1 traveler; flights+taxi total $274, plus 6 hotel nights and 20 meals must stay comfortably under $1,800. State the estimated total on one line AFTER the JSON block.",
  "",
  "Output the JSON object inside a single ```json code block with keys idx, query, plan (7 objects, keys day, current_city, transportation, breakfast, attraction, lunch, dinner, accommodation)."
].join("\n");

const plan = await phase("assemble", async () => agent(assemblePrompt, { model: "opus" }));

return plan;
