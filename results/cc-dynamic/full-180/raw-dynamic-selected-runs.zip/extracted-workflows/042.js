export const meta = {
  name: "tn-itinerary-162",
  description: "Plan a 7-day Houston -> 3-city Tennessee itinerary for 2 travelers under $8200 (party-friendly private rooms, no self-driving)",
  phases: 3
};

const txt = (r) =>
  typeof r === "string"
    ? r
    : (r && (r.result ?? r.text ?? r.output ?? r.content)) ?? JSON.stringify(r);

const cityPrompt = (city) => `You are gathering TravelPlanner data for ${city}, Tennessee.
Trip context: 2 travelers, 2022-03-21 to 2022-03-27, budget $8200 total, they need accommodations that ALLOW PARTIES and prefer PRIVATE ROOMS, and they will NOT self-drive.

Make AT MOST 4 tool calls total, then report. If a tool returns nothing, try ONE alternative and move on. Never loop or retry repeatedly.

Calls to make:
1. mcp__travelplanner__search_accommodations with city "${city}"
2. mcp__travelplanner__search_restaurants with city "${city}"
3. mcp__travelplanner__search_attractions with city "${city}"

From the accommodations table, select the 3 CHEAPEST rows that satisfy ALL of:
- house rules ALLOW parties (the rules must NOT contain "No parties")
- maximum occupancy >= 2
- minimum nights <= 2
Prefer room type "Private room". If no party-allowing private room exists, say so explicitly and give the best party-allowing alternative with its room type.
For each selected accommodation report EXACTLY: name | price per night | room type | minimum nights | maximum occupancy | house rules.

From restaurants: list 6 rows as: name | average cost | cuisine.
From attractions: list 4 names exactly as returned.

Report compact plain text under the heading "${city}". Use only exact names from the tools; invent nothing.`;

const transportPrompt = `You are researching TravelPlanner transportation for 2 travelers who refuse to self-drive.

Route skeleton (fixed, do not change):
- Day 1, 2022-03-21: Houston -> Nashville (ALREADY CHOSEN, do NOT search this leg)
- Day 3, 2022-03-23: Nashville -> Knoxville
- Day 5, 2022-03-25: Knoxville -> Memphis
- Day 7, 2022-03-27: Memphis -> Houston

Make AT MOST 5 tool calls total. Never retry a tool more than once.
1. mcp__travelplanner__search_flights origin "Nashville" destination "Knoxville" departure_date "2022-03-23"
2. mcp__travelplanner__search_flights origin "Knoxville" destination "Memphis" departure_date "2022-03-25"
3. mcp__travelplanner__search_flights origin "Memphis" destination "Houston" departure_date "2022-03-27"

For any leg that returns NO flights, make ONE mcp__travelplanner__compute_distance call for that leg with mode "taxi" and report the exact cost, duration and distance returned. If you would exceed 5 total calls, report "unknown" for the remaining legs instead.

Report per leg, plain text:
- leg name
- if flights exist: the CHEAPEST flight as: Flight Number, price, DepTime, ArrTime
- if no flights: taxi cost, duration, distance (exact numbers from the tool)`;

const cityReports = await phase("research-cities", () =>
  parallel([
    agent(cityPrompt("Nashville"), { description: "Research Nashville" }),
    agent(cityPrompt("Knoxville"), { description: "Research Knoxville" }),
    agent(cityPrompt("Memphis"), { description: "Research Memphis" })
  ])
);

const transportReport = await phase("research-transport", () =>
  agent(transportPrompt, { description: "Research inter-city transport" })
);

const combined = [
  "=== CITY REPORTS ===",
  ...cityReports.map(txt),
  "=== TRANSPORT REPORT ===",
  txt(transportReport)
].join("\n\n");

return combined;
