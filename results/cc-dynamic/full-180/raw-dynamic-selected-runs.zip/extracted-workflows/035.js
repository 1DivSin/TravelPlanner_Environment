export const meta = {
  name: "ny-3city-travelplanner-data",
  description: "Gather lodging (visitors allowed), dining (French/Italian/Chinese/American) and attraction data for Buffalo, Rochester and Syracuse NY",
  phases: 1
};

const cityPrompt = (city) => `You are gathering TravelPlanner data for ${city}, New York, for a 2-person trip (March 13-19, 2022).

Make EXACTLY these three tool calls, in this order, and no others:
1. mcp__travelplanner__search_accommodations with city="${city}"
2. mcp__travelplanner__search_restaurants with city="${city}"
3. mcp__travelplanner__search_attractions with city="${city}"

If one of those tools returns nothing, call it ONE more time and then move on. Never loop.

Then output a compact plain-text report, no commentary, in exactly this form:

ACCOMMODATIONS (${city}): up to 6 options whose house rules ALLOW visitors (house rules must NOT contain "No visitors"). One per line:
NAME | price per night | room type | minimum nights | maximum occupancy | house rules
Prefer options with minimum nights <= 2 and maximum occupancy >= 2.

RESTAURANTS (${city}): for EACH cuisine French, Italian, Chinese, American list up to 3 matching restaurants, one per line:
CUISINE :: NAME | all cuisines listed | average cost
If a cuisine has no match in this city, write "CUISINE :: none".

ATTRACTIONS (${city}): exact names of up to 6 attractions, one per line.

Copy every name EXACTLY as the tools return it, character for character. Do not invent, translate, or shorten names.`;

const results = await parallel([
  () => agent(cityPrompt("Buffalo"), { model: "sonnet" }),
  () => agent(cityPrompt("Rochester"), { model: "sonnet" }),
  () => agent(cityPrompt("Syracuse"), { model: "sonnet" })
]);

const text = results
  .map((r) => (typeof r === "string" ? r : (r && (r.result ?? r.output ?? r.text)) ?? JSON.stringify(r)))
  .join("\n\n===== NEXT CITY =====\n\n");

return text;
