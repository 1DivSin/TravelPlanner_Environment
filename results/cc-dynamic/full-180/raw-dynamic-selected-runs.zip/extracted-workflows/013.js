export const meta = {
  name: "tp-birmingham-florida-5day",
  description: "Plan a 5-day solo trip from Birmingham to Orlando + Tampa (2022-03-26 to 2022-03-30) under $3,500",
  phases: 2
};

const RULES = `
HARD LIMITS: make at most 4 tool calls total. If a tool returns no results, try ONE alternative, then stop and report what you found. Never retry the same call.
Copy every name, number, and price VERBATIM from tool output. Never invent data.
`;

const [orlando, tampa] = await parallel([
  () => agent(`You research on-the-ground options in Orlando, Florida only.
${RULES}
Tool calls to make:
1. mcp__travelplanner__search_accommodations(city="Orlando")
2. mcp__travelplanner__search_restaurants(city="Orlando")
3. mcp__travelplanner__search_attractions(city="Orlando")

REPORT (plain text, no preamble):
- ACCOMMODATIONS: 6 options that allow a stay of exactly 2 nights (minimum nights <= 2) and maximum occupancy >= 1, cheapest first, each as: Name | price per night | room type | minimum nights | maximum occupancy
- RESTAURANTS: 8 options spanning cheap to mid price, each as: Name | average cost | cuisine
- ATTRACTIONS: 6 options, each as: Name | city`),

  () => agent(`You research on-the-ground options in Tampa, Florida only.
${RULES}
Tool calls to make:
1. mcp__travelplanner__search_accommodations(city="Tampa")
2. mcp__travelplanner__search_restaurants(city="Tampa")
3. mcp__travelplanner__search_attractions(city="Tampa")

REPORT (plain text, no preamble):
- ACCOMMODATIONS: 6 options that allow a stay of exactly 2 nights (minimum nights <= 2) and maximum occupancy >= 1, cheapest first, each as: Name | price per night | room type | minimum nights | maximum occupancy
- RESTAURANTS: 8 options spanning cheap to mid price, each as: Name | average cost | cuisine
- ATTRACTIONS: 6 options, each as: Name | city`)
]);

const plan = await agent(`You are finalizing a TravelPlanner itinerary. Use ONLY the data below. Do NOT call any tools. Do NOT invent names, prices, or times.

TRIP: 1 solo traveler. Origin Birmingham. Visiting 2 Florida cities: Orlando then Tampa. 5 days: 2022-03-26 (day 1), 03-27 (day 2), 03-28 (day 3), 03-29 (day 4), 03-30 (day 5). TOTAL BUDGET: $3,500.

=== TRANSPORTATION (already verified, use verbatim) ===
Day 1 Birmingham -> Orlando, 2022-03-26: Flight Number: F4015589, price 236, Departure Time: 05:20, Arrival Time: 07:38
Day 3 Orlando -> Tampa, 2022-03-28: no flights exist. Ground only:
  Self-driving, from Orlando to Tampa, duration: 1 hour 18 mins, distance: 136 km, cost: 6
  Taxi, from Orlando to Tampa, duration: 1 hour 18 mins, distance: 136 km, cost: 136
Day 5 Tampa -> Birmingham, 2022-03-30: Flight Number: F3989297, price 134, Departure Time: 16:44, Arrival Time: 17:08

=== ORLANDO RESEARCH ===
${orlando}

=== TAMPA RESEARCH ===
${tampa}

RULES:
- Use flight F4015589 outbound and F3989297 on day 5. Use "Self-driving" for the day-3 Orlando -> Tampa leg.
- Nights: Orlando on Mar 26 and Mar 27 (2 nights), Tampa on Mar 28 and Mar 29 (2 nights). Day 5 accommodation is "-".
- Pick ONE Orlando accommodation (reuse days 1-2) and ONE Tampa accommodation (reuse days 3-4). Both must have minimum nights <= 2.
- Every restaurant name must be distinct across the whole 5 days; never reuse one. Every attraction must be distinct too.
- Meals and attractions on days 1-2 must be Orlando entries; days 3-5 must be Tampa entries. Day 3 lunch/dinner in Tampa (drive is short); day 3 breakfast in Orlando is fine.
- Day 1 breakfast is "-" (05:20 departure). Day 5 dinner is "-" (flight lands 17:08 in Birmingham); day 5 breakfast and lunch are Tampa entries, day 5 attraction may be "-".
- transportation format EXACTLY: flights -> "Flight Number: F4015589, from Birmingham to Orlando, Departure Time: 05:20, Arrival Time: 07:38"; driving -> "Self-driving, from Orlando to Tampa, duration: 1 hour 18 mins, distance: 136 km, cost: 6". Days with no travel use "-".
- Total cost = 2 flights + self-driving cost + 4 nights lodging + every meal at its average cost (attractions free) and MUST stay well under $3,500.

OUTPUT: first one line of cost arithmetic with the total, then the final answer as a single JSON object in a markdown json code block with keys idx (38), query (echo verbatim below), and plan (array of 5 day objects with keys day, current_city, transportation, breakfast, attraction, lunch, dinner, accommodation, in that order).
query = "Could you create a travel plan for a solo traveler starting from Birmingham and visiting 2 cities in Florida, for a duration of 5 days, from March 26th to March 30th, 2022? The allotted budget for this trip is $3,500."
current_city: day 1 = "from Birmingham to Orlando", day 2 = "Orlando", day 3 = "from Orlando to Tampa", day 4 = "Tampa", day 5 = "from Tampa to Birmingham".
attraction: semicolon-separated "Name, City;" entries. meals: "Name, City". accommodation: "Name, City".`);

return plan;
