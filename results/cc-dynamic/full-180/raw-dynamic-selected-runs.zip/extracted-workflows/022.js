export const meta = {
  name: "va-3city-research",
  description: "Gather accommodations, restaurants, attractions for Richmond, Newport News, Norfolk for a 7-day March 2022 trip",
  phases: 1
};

const RULES = "\nHard limits: make AT MOST 4 tool calls total, then answer. If a search returns no rows, try ONE alternative and move on. Never retry the same call. Do not use the notebook tools. Answer with compact plain text, no preamble.\n";

const cityScout = (city, nights) => `You are gathering TravelPlanner data for ${city}, Virginia for a 1-person trip in March 2022. The traveler needs ${nights} consecutive nights there.
Make exactly these 3 calls: mcp__travelplanner__search_accommodations(city="${city}"), mcp__travelplanner__search_restaurants(city="${city}"), mcp__travelplanner__search_attractions(city="${city}").
Report, copying names EXACTLY as printed in the data (do not paraphrase or fix spelling or capitalization):
- ACCOMMODATIONS: the 3 cheapest entries whose "maximum occupancy" >= 1 AND "minimum nights" <= ${nights}, as: NAME | price | room type | minimum nights | maximum occupancy | house rules.
- RESTAURANTS: 8 distinct restaurants as: NAME | Average Cost | Cuisines. Prefer a mix with several under $40.
- ATTRACTIONS: 6 distinct attraction names exactly as printed.
${RULES}`;

const results = await parallel([
  () => agent(cityScout("Richmond", 2), { model: "sonnet" }),
  () => agent(cityScout("Newport News", 2), { model: "sonnet" }),
  () => agent(cityScout("Norfolk", 2), { model: "sonnet" })
]);

const asText = (x) => {
  if (x == null) return "(no result)";
  if (typeof x === "string") return x;
  return x.result ?? x.text ?? x.output ?? JSON.stringify(x);
};

const arr = Array.isArray(results) ? results : [results];

return `## RICHMOND (nights of Mar 15-16)
${asText(arr[0])}

## NEWPORT NEWS (nights of Mar 17-18)
${asText(arr[1])}

## NORFOLK (nights of Mar 19-20)
${asText(arr[2])}
`;
