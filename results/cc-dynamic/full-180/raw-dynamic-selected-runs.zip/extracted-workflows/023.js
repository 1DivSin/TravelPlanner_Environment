export const meta = {
  name: "travelplanner-washington-3day",
  description: "Plan a 3-day St. Louis to Washington itinerary (Mar 1-3, 2022) under a $1,500 budget",
  phases: 2
};

const txt = (r) => {
  if (r == null) return "";
  if (typeof r === "string") return r;
  return r.result ?? r.text ?? r.output ?? r.report ?? JSON.stringify(r);
};

const RULES = `
Hard rules:
- Use ONLY the mcp__travelplanner__* tools. Make at most 5 tool calls total.
- If a search returns nothing, try ONE alternative spelling and then stop. Never loop or retry repeatedly.
- Do NOT invent data. Report only what the tools actually returned, copied verbatim.
- Be compact: no prose analysis, just the structured listing requested.
`;

const [flightRes, localRes] = await parallel([
  () => agent(`You are gathering flight data for a TravelPlanner itinerary.

Trip: 1 traveler, origin city "St. Louis", destination city "Washington" (Washington, District of Columbia), 3-day trip 2022-03-01 to 2022-03-03.

Do exactly this:
1. mcp__travelplanner__search_flights(origin="St. Louis", destination="Washington", departure_date="2022-03-01")
2. mcp__travelplanner__search_flights(origin="Washington", destination="St. Louis", departure_date="2022-03-03")
3. If either search returns no rows, retry that leg ONCE with origin/destination spelled "Saint Louis", then stop.

Then report:
- OUTBOUND 2022-03-01: the 5 cheapest flights, each as: Flight Number | price | DepTime | ArrTime | actual OriginCity -> DestCity strings exactly as returned.
- RETURN 2022-03-03: same, 5 cheapest.
- Note the exact city name strings the tool uses (e.g. "Washington" vs "Washington, DC").
${RULES}`, { model: "sonnet", description: "Flights St. Louis<->Washington" }),

  () => agent(`You are gathering on-the-ground data in Washington (District of Columbia) for a TravelPlanner itinerary.

Trip: 1 traveler, city "Washington", 2 nights (check in 2022-03-01, check out 2022-03-03), total trip budget $1,500.

Do exactly this (3 tool calls, no more):
1. mcp__travelplanner__search_accommodations(city="Washington")
2. mcp__travelplanner__search_restaurants(city="Washington")
3. mcp__travelplanner__search_attractions(city="Washington")

Then report:
- ACCOMMODATIONS: the 5 best-value options whose "minimum nights" is <= 2 and whose maximum occupancy is >= 1. For each: exact NAME | price per night | room type | minimum nights | maximum occupancy | house rules.
- RESTAURANTS: 9 options spread across price levels. For each: exact NAME | average cost | cuisines.
- ATTRACTIONS: 6 options. For each: exact NAME (verbatim, including punctuation) | city.
${RULES}`, { model: "sonnet", description: "Washington hotels, food, attractions" })
]);

const final = await agent(`You are assembling the FINAL TravelPlanner answer. All data is already gathered; do NOT call any tools.

USER QUERY:
"Can you help draft a 3-day travel plan, starting on March 1st, 2022 and ending on March 3rd, 2022, for one person departing from St. Louis and heading to Washington with a budget of $1,500?"

=== FLIGHT DATA ===
${txt(flightRes)}

=== WASHINGTON DATA ===
${txt(localRes)}

Build a 3-day plan for 1 traveler, 2022-03-01 to 2022-03-03:
- Day 1: fly St. Louis -> Washington (cheapest reasonable outbound). current_city = "from St. Louis to Washington". breakfast "-", then attraction(s), lunch, dinner, accommodation.
- Day 2: current_city = "Washington". All three meals, 2 attractions, same accommodation.
- Day 3: fly Washington -> St. Louis. current_city = "from Washington to St. Louis". breakfast and lunch in Washington, dinner "-", accommodation "-", 1 attraction or "-".
- Use the SAME accommodation both nights, and it must have minimum nights <= 2.
- Never reuse the same restaurant twice across the whole trip.
- Copy names verbatim from the data. Every meal/attraction/hotel city is "Washington".
- Keep total cost (2 flights + 2 nights lodging + meals) comfortably under $1,500 and state the arithmetic in ONE short line BEFORE the JSON block.
- transportation format exactly: "Flight Number: <num>, from St. Louis to Washington, Departure Time: <HH:MM>, Arrival Time: <HH:MM>" (and the reverse on day 3).

Output: one short budget line, then a single \`\`\`json code block containing exactly:
{"idx": 17, "query": "<the user query verbatim>", "plan": [ {day, current_city, transportation, breakfast, attraction, lunch, dinner, accommodation} x3 ]}
attraction entries are semicolon-separated "<Name>, Washington;" strings.`, { model: "opus", description: "Assemble final itinerary JSON" });

return txt(final);
