export const meta = {
  name: "travelplanner-idx81",
  description: "Research Orlando + Miami options in parallel, then assemble a 5-day Knoxville->Florida itinerary JSON under $3900 for 2 travelers.",
  phases: 2,
};

const COMMON = `
You are helping build one TravelPlanner itinerary. Facts already established (do NOT re-search flights):
- 2 travelers, 5 days, 2022-03-20 .. 2022-03-24, budget $3900 total, origin Knoxville.
- Day 1 (03-20): Flight F3566154 Knoxville->Orlando 09:17-11:08, $235/person.
- Day 3 (03-22): Flight F3682996 Orlando->Miami 16:40-17:54, $54/person.
- Day 5 (03-24): Flight F3601007 Miami->Knoxville 21:30-23:58, $217/person.
- Flights total $1012 for two. About $2880 remains for lodging + meals + attractions.
- Lodging nights: Orlando 03-20 and 03-21 (2 nights). Miami 03-22 and 03-23 (2 nights).
- Cuisine wish: Chinese and Mediterranean.

HARD RULES you must respect when recommending:
- Accommodation "minimum nights" must be <= the nights stayed in that city (<= 2 here). Reject any option needing 3+ nights.
- Accommodation "maximum occupancy" must be >= 2.
- Report house rules verbatim (parties / smoking / children / pets / visitors) so the assembler can filter.
- Copy names EXACTLY as the tool returns them. Never invent a name.

TOOL BUDGET: at most 5 tool calls. If a search returns nothing, try ONE alternative then move on.
`;

const cityAgent = (city) => () =>
  agent(
    `${COMMON}
Your city: ${city}.
Do exactly these calls: search_accommodations("${city}"), search_restaurants("${city}"), search_attractions("${city}").

Then report back a COMPACT summary, no prose padding:
1) ACCOMMODATIONS: the 3 cheapest options that satisfy minimum-nights <= 2 AND maximum occupancy >= 2. For each: exact name, price per night, room type, minimum nights, max occupancy, house rules.
2) RESTAURANTS: up to 4 Chinese and up to 4 Mediterranean options in ${city}. For each: exact name, cuisine list, average cost. If a cuisine is missing entirely, say so explicitly and list 2 cheap alternatives instead.
3) ATTRACTIONS: 6 attractions with exact names as returned.
Keep it under 400 words.`,
    { model: "sonnet", description: `Research ${city} options` }
  );

const [orlando, miami] = await phase(1, "city research", () =>
  parallel([cityAgent("Orlando"), cityAgent("Miami")])
);

const final = await phase(2, "assemble itinerary", () =>
  agent(
    `${COMMON}
You are the assembler. Do NOT call any tools. Use ONLY the researched options below.

=== ORLANDO RESEARCH ===
${orlando}

=== MIAMI RESEARCH ===
${miami}

Build the 5-day plan:
- Day 1: current_city "from Knoxville to Orlando", transportation "Flight Number: F3566154, from Knoxville to Orlando, Departure Time: 09:17, Arrival Time: 11:08", breakfast "-" (flight departs early), lunch + dinner in Orlando, 1-2 Orlando attractions, Orlando accommodation.
- Day 2: current_city "Orlando", transportation "-", all 3 meals in Orlando, 2 attractions, same Orlando accommodation.
- Day 3: current_city "from Orlando to Miami", transportation "Flight Number: F3682996, from Orlando to Miami, Departure Time: 16:40, Arrival Time: 17:54". Breakfast + lunch in Orlando, dinner in Miami, attractions in Orlando (morning) and/or "-", Miami accommodation.
- Day 4: current_city "Miami", transportation "-", 3 meals in Miami, 2 attractions, same Miami accommodation.
- Day 5: current_city "from Miami to Knoxville", transportation "Flight Number: F3601007, from Miami to Knoxville, Departure Time: 21:30, Arrival Time: 23:58". Breakfast/lunch/dinner in Miami (late flight allows dinner), 1-2 Miami attractions, accommodation "-".

Constraints to satisfy:
- NEVER repeat a restaurant anywhere in the plan. Each restaurant name appears at most once across all 5 days.
- Include at least one Chinese and at least one Mediterranean restaurant across the trip (prefer both cities).
- Meals and attractions must be in the city you are in that day (day 1 = destination city; day 3 = either Orlando before the flight or Miami after; day 5 = Miami).
- Total cost = flights 1012 + (nightly rate x nights, one room, since max occupancy >= 2) + (2 x average cost per person per meal) must be <= 3900. Compute it and state the total.

Output format: first a single line "TOTAL_COST: $<number>", then the JSON object in a \`\`\`json code block with keys idx (81), query, plan. Use exactly these plan keys: day, current_city, transportation, breakfast, attraction, lunch, dinner, accommodation. attraction entries are "<Name>, <City>;" concatenated. Meals/accommodation are "<Name>, <City>".
The query string is exactly: Could you tailor a 5-day travel plan for two people, departing from Knoxville and visiting 2 cities in Florida from March 20 to March 24, 2022? Our budget is set at $3,900. We'd love to explore local Chinese and Mediterranean cuisines during our stay.`,
    { model: "sonnet", description: "Assemble final itinerary JSON" }
  )
);

return final;
