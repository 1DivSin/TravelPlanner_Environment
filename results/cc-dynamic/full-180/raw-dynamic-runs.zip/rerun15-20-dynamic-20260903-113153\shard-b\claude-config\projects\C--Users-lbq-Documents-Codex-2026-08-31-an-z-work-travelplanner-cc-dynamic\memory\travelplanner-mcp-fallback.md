---
name: travelplanner-mcp-fallback
description: "When the travelplanner MCP server fails to connect, query the TravelPlanner CSV databases directly with Grep instead."
metadata: 
  node_type: memory
  type: project
  originSessionId: 8ca49968-d2c6-4888-b305-aa480da156ec
  modified: 2026-09-03T03:40:25.060Z
---

In this workspace the `travelplanner` MCP stdio server (`experiment/mcp_server.py`, configured in `experiment/mcp.json`) sometimes reports `Failed to connect`, and Bash execution is separately blocked in "don't ask" permission mode. Observed 2026-09-03.

**Why:** Without either channel, the flights/accommodations/restaurants/attractions tools appear unavailable and an itinerary task looks blocked.

**How to apply:** Fall back to `Grep` over the CSVs under `TravelPlanner/database/`:
- `flights/clean_Flights_2022.csv` — `Flight Number,Price,DepTime,ArrTime,ActualElapsedTime,FlightDate,OriginCityName,DestCityName,Distance`; match `,<YYYY-MM-DD>,<Origin>,<Dest>,`
- `accommodations/clean_accommodations_2022.csv` — `,NAME,room type,price,minimum nights,review rate number,house_rules,maximum occupancy,city`
- `restaurants/clean_restaurant_2022.csv` — `,Name,City,Cuisines,Average Cost,Aggregate Rating`
- `attractions/attractions.csv` — `Name,Latitude,Longitude,Address,Phone,Website,City`
- `googleDistanceMatrix/distance.csv` for driving/taxi legs

Anchor city matches with `,<City>$` or a leading-field regex. Note some restaurant names contain mojibake (e.g. `Hearken Caf愆`) — prefer ASCII-clean names so the emitted plan matches the evaluator.
