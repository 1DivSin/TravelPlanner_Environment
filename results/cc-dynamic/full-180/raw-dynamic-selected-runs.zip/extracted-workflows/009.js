export const meta = {
  name: "travelplanner-sf-flights-idx19",
  description: "Fetch Seattle<->San Francisco flight rows and verify the chosen San Francisco accommodation row",
  phases: 1
};

const txt = (r) => {
  if (r == null) return "";
  if (typeof r === "string") return r;
  return r.result ?? r.text ?? r.output ?? r.report ?? JSON.stringify(r);
};

const res = await agent(`You are gathering flight and accommodation data for a TravelPlanner itinerary. You DO have MCP tools named mcp__travelplanner__search_flights, mcp__travelplanner__search_accommodations and mcp__travelplanner__compute_distance available. Use them.

Trip: 1 traveler, origin city "Seattle", destination city "San Francisco", 2022-03-21 to 2022-03-23.

Make exactly these 3 tool calls (no more, no loops, no retries beyond ONE fallback):
1. mcp__travelplanner__search_flights(origin="Seattle", destination="San Francisco", departure_date="2022-03-21")
2. mcp__travelplanner__search_flights(origin="San Francisco", destination="Seattle", departure_date="2022-03-23")
3. mcp__travelplanner__search_accommodations(city="San Francisco")

If a flight search returns no rows, make ONE fallback call: mcp__travelplanner__compute_distance(origin="Seattle", destination="San Francisco", mode="taxi") and report its output verbatim.

Then report, copied VERBATIM from tool output (no invention, no rounding):
- OUTBOUND 2022-03-21: the 5 cheapest rows as: Flight Number | Price | DepTime | ArrTime | OriginCityName -> DestCityName
- RETURN 2022-03-23: the 5 cheapest rows in the same format.
- ACCOMMODATION CHECK: the row whose NAME is exactly "Room in Down town Brooklyn Parkslop" — report NAME | price | room type | minimum nights | maximum occupancy | house rules. If that exact name is not present, say "NOT FOUND" and instead list the 4 cheapest San Francisco rows with minimum nights <= 2 and maximum occupancy >= 1, same fields.

Be compact. No analysis, just the listings. If a tool call errors, state the exact error text.`, { model: "sonnet", description: "SEA<->SFO flights + hotel verification" });

return txt(res);
