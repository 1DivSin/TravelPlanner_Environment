---
name: workflow-parallel-needs-thunks
description: "Workflow scripts must pass functions (not already-created promises) to parallel(), or the phase silently returns zero agents"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: af4d63d2-3e12-494d-a1d9-3b76700009a1
  modified: 2026-08-31T15:35:41.241Z
---

In Workflow tool scripts, `parallel([...])` takes an array of thunks (`() => agent(...)`), not an array of already-invoked `agent(...)` promises. Passing bare `agent(...)` calls makes the run finish instantly with `agentCount: 0`, no `journal.jsonl`, and only `workflow_phase` entries in `workflowProgress`.

**Why:** two TravelPlanner runs were wasted this way; the failure looks like a model/API problem rather than a script bug, so it is easy to misdiagnose.

**How to apply:** write `await parallel([() => agent(A), () => agent(B)])`. If a workflow completes in well under a second with `agentCount: 0`, suspect this first. Prefer iterating via the persisted script file + `scriptPath`, but note the harness may deny edits to that file under don't-ask permission mode — in that case just re-invoke Workflow with the corrected inline `script`. Also `return` a joined string of agent results from the script so the output file carries the data.
