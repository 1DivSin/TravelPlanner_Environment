export const meta = {
  name: "pa-3city-itinerary",
  description: "Gather TravelPlanner data for a 7-day St. Louis -> Pennsylvania 3-city trip (Mar 23-29 2022, 2 people, $7200).",
  phases: 3,
};

const CITY_BRIEF = (city) => `You are gathering TravelPlanner data for ${city}, Pennsylvania for a 7-day trip (March 23-29, 2022, 2 travelers, cuisine interest: Indian and American).

Make AT MOST 3 tool calls, in this order:
1. mcp__travelplanner__search_accommodations with city "${city}"
2. mcp__travelplanner__search_restaurants with city "${city}"
3. mcp__travelplanner__search_attractions with city "${city}"

If a tool returns no results, do NOT retry it. Just note "none" and move on.

Report back COMPACT plain text, no commentary:
ACCOMMODATIONS (up to 4 cheapest that allow at least 2 people, i.e. maximum occupancy >= 2, and minimum nights <= 2): exact name | price per night | room type | minimum nights | maximum occupancy
RESTAURANTS (up to 8; PRIORITIZE any with Indian cuisine, then American cuisine; include the cuisines field verbatim): exact name | average cost | cuisines
ATTRACTIONS (up to 5): exact name

Use exact names verbatim from the tool output. Do not invent anything.`;

const cityResults = await parallel([
  () => agent(CITY_BRIEF("Philadelphia"), { model: "sonnet", name: "philadelphia-scout" }),
  () => agent(CITY_BRIEF("Harrisburg"), { model: "sonnet", name: "harrisburg-scout" }),
  () => agent(CITY_BRIEF("Pittsburgh"), { model: "sonnet", name: "pittsburgh-scout" }),
]);

const transport = await agent(
  `You are gathering transportation data for a trip: St. Louis -> Philadelphia -> Harrisburg -> Pittsburgh -> St. Louis, March 2022, 2 travelers.

Make AT MOST 5 tool calls total:
1. mcp__travelplanner__search_flights origin "Pittsburgh", destination "St. Louis", departure_date "2022-03-29"
2. mcp__travelplanner__compute_distance origin "Philadelphia", destination "Harrisburg", mode "driving"
3. mcp__travelplanner__compute_distance origin "Harrisburg", destination "Pittsburgh", mode "driving"
4. mcp__travelplanner__compute_distance origin "Philadelphia", destination "Harrisburg", mode "taxi"
5. mcp__travelplanner__compute_distance origin "Harrisburg", destination "Pittsburgh", mode "taxi"

If a call returns nothing, do NOT retry; note "none" and continue.

Report back COMPACT plain text, verbatim strings from the tools:
RETURN FLIGHTS (up to 3): Flight Number | price | dep time | arr time
PHL->HAR driving: the exact tool output string (duration, distance, cost)
HAR->PIT driving: the exact tool output string
PHL->HAR taxi: the exact tool output string
HAR->PIT taxi: the exact tool output string`,
  { model: "sonnet", name: "transport-scout" }
);

return {
  philadelphia: cityResults[0],
  harrisburg: cityResults[1],
  pittsburgh: cityResults[2],
  transport,
  outboundFlightsAlreadyKnown:
    "St. Louis -> Philadelphia 2022-03-23: F3787538 $232 05:26->08:29; F4008247 $231 20:09->23:04; F4055118 $337 16:57->19:58",
};
