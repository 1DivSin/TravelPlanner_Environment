export const meta = {
  name: "va-3city-idx48",
  description: "Research 3 Virginia cities in parallel, then assemble a 7-day Philadelphia-origin itinerary under $2900",
  phases: ["city-research", "assemble"]
};

const RULES = [
  "",
  "HARD LIMITS: make AT MOST 4 tool calls total, then answer immediately.",
  "If a call returns no rows, try ONE alternative and move on. Never repeat the same call.",
  "Do not use notebook tools. Do not read or write files. Answer in compact plain text, no preamble."
].join("\n");

const legs = [
  { city: "Richmond", stay: "nights of Mar 2 and Mar 3 (days 1-2)" },
  { city: "Newport News", stay: "nights of Mar 4 and Mar 5 (days 3-4)" },
  { city: "Norfolk", stay: "nights of Mar 6 and Mar 7 (days 5-6)" }
];

const cityPrompt = (leg) => [
  "You are gathering TravelPlanner data for " + leg.city + ", Virginia, for a 1-traveler trip in March 2022.",
  "The traveler stays there for the " + leg.stay + " (2 consecutive nights).",
  "Make EXACTLY these 3 tool calls, once each:",
  "1. mcp__travelplanner__search_accommodations(city=\"" + leg.city + "\")",
  "2. mcp__travelplanner__search_restaurants(city=\"" + leg.city + "\")",
  "3. mcp__travelplanner__search_attractions(city=\"" + leg.city + "\")",
  "Report, copying names EXACTLY as printed (do not paraphrase, fix spelling, or change capitalization):",
  "- ACCOMMODATIONS: the 3 cheapest rows whose \"maximum occupancy\" >= 1 AND \"minimum nights\" <= 2, as: NAME | price | room type | minimum nights | maximum occupancy.",
  "- RESTAURANTS: 9 distinct restaurants as: NAME | Average Cost. Prefer a spread including several under $40.",
  "- ATTRACTIONS: 6 distinct attraction NAMES exactly as printed.",
  RULES
].join("\n");

const findings = await phase("city-research", () =>
  parallel(legs.map((leg) => () => agent(cityPrompt(leg), { model: "sonnet" })))
);

const asText = (x) => {
  if (x == null) return "(no result)";
  if (typeof x === "string") return x;
  return x.result ?? x.text ?? x.output ?? JSON.stringify(x);
};

const arr = Array.isArray(findings) ? findings : [findings];

const assemblePrompt = [
  "Assemble the final TravelPlanner JSON itinerary. Do NOT call any tools. Use ONLY the data below.",
  "",
  "Query (idx 48): \"I require a travel itinerary for a seven-day trip beginning on March 2nd and ending on March 8th, 2022. The trip will begin in Philadelphia and involve visiting 3 cities in Virginia. The available budget for the trip is $2,900.\"",
  "1 traveler. Budget $2,900.",
  "",
  "FIXED TRANSPORTATION (copy these strings verbatim):",
  "Day 1: Flight Number: F3734535, from Philadelphia to Richmond, Departure Time: 09:40, Arrival Time: 10:51",
  "Day 3: taxi, from Richmond to Newport News, duration: 1 hour 5 mins, distance: 110 km, cost: 110",
  "Day 5: taxi, from Newport News to Norfolk, duration: 37 mins, distance: 40.9 km, cost: 40",
  "Day 7: Flight Number: F3796824, from Norfolk to Philadelphia, Departure Time: 08:40, Arrival Time: 09:44",
  "Days 2, 4, 6: \"-\"",
  "",
  "CITY RESEARCH:",
  "--- RICHMOND (days 1-2) ---",
  asText(arr[0]),
  "",
  "--- NEWPORT NEWS (days 3-4) ---",
  asText(arr[1]),
  "",
  "--- NORFOLK (days 5-6) ---",
  asText(arr[2]),
  "",
  "STRUCTURE (exact current_city values):",
  "Day 1 \"from Philadelphia to Richmond\"; Day 2 \"Richmond\"; Day 3 \"from Richmond to Newport News\"; Day 4 \"Newport News\"; Day 5 \"from Newport News to Norfolk\"; Day 6 \"Norfolk\"; Day 7 \"from Norfolk to Philadelphia\".",
  "",
  "ACCOMMODATION: pick ONE qualifying hotel per city (minimum nights <= 2, maximum occupancy >= 1). Richmond hotel on days 1 and 2; Newport News hotel on days 3 and 4; Norfolk hotel on days 5 and 6; \"-\" on day 7. Format \"<Name>, <City>\". Repeat the same name across its own consecutive nights.",
  "",
  "MEALS: every filled slot must be a real restaurant from the city the traveler is physically in at that meal time, formatted \"<Name>, <City>\". NEVER reuse a restaurant name anywhere in the 7 days.",
  "- Day 1: breakfast \"-\", lunch Richmond, dinner Richmond.",
  "- Day 2: all three Richmond.",
  "- Day 3: breakfast Richmond, lunch Newport News, dinner Newport News.",
  "- Day 4: all three Newport News.",
  "- Day 5: breakfast Newport News, lunch Norfolk, dinner Norfolk.",
  "- Day 6: all three Norfolk.",
  "- Day 7: breakfast \"-\", lunch \"-\", dinner \"-\" (early morning flight home).",
  "That is 16 distinct restaurants total. Days 2, 4, 6 MUST have all three meals filled.",
  "",
  "ATTRACTIONS: 1-2 per day, each formatted \"<Name>, <City>;\" with a trailing semicolon (join two with a semicolon so the string ends in \";\"). Attractions must be in the city the traveler is in that day. NEVER reuse an attraction. Days 2, 4, and 6 MUST have at least one attraction. Day 7 attraction is \"-\".",
  "",
  "BUDGET: flight $47 + return flight $89 + taxis $150 = $286, plus 6 hotel nights and the meals must total under $2,900. The budget is generous, so mid-range picks are fine, but never exceed it.",
  "",
  "OUTPUT: return ONLY a single ```json code block containing an object with keys idx (48), query (the exact query string above), and plan (array of 7 objects, each with keys day, current_city, transportation, breakfast, attraction, lunch, dinner, accommodation). No text outside the code block."
].join("\n");

const plan = await phase("assemble", () => agent(assemblePrompt, { model: "opus" }));

return plan;
