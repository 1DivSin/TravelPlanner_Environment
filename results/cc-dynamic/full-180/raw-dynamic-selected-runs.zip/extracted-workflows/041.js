export const meta = {
  name: "wisconsin-itinerary-v3",
  description: "Gather Wisconsin lodging/dining/attraction options and driving legs for a 5-day no-flight Charlotte trip",
  phases: 2
};

const cityPrompt = (city) => `Gather raw options for a TravelPlanner itinerary in ${city}, Wisconsin. Trip: 2 adults plus children under 10, March 18-22 2022, no flights.

Use the travelplanner MCP tools. Make AT MOST 3 tool calls, in this order:
1. search_accommodations with city="${city}"
2. search_restaurants with city="${city}"
3. search_attractions with city="${city}"

Never retry a call and never loop. If one returns nothing, skip it and continue.

Then report ONLY this, using names copied VERBATIM from the tool output:

CITY: ${city}
ACCOMMODATIONS - keep only rows whose room type is "Private room" AND whose house rules do NOT contain "No children under 10". List the 4 cheapest as: NAME | price | minimum nights | maximum occupancy | room type | house rules
RESTAURANTS - list 8 as: NAME | average cost
ATTRACTIONS - list 6 as: NAME

No commentary, no analysis.`;

const cityResults = await parallel([
  () => agent(cityPrompt("Milwaukee"), { description: "Research Milwaukee options" }),
  () => agent(cityPrompt("Madison"), { description: "Research Madison options" })
]);

const legs = await agent(`Compute driving legs for a no-flight trip. Use the travelplanner compute_distance tool with mode="driving". Make EXACTLY these 3 calls:
1. origin="Charlotte", destination="Milwaukee"
2. origin="Milwaukee", destination="Madison"
3. origin="Madison", destination="Charlotte"

Never retry. Report the three result strings VERBATIM, one per line, nothing else.`, { description: "Compute driving legs" });

return JSON.stringify({ cities: cityResults, legs: legs }, null, 2);
