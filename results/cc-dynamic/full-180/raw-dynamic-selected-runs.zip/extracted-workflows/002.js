export const meta = {
  name: "travelplanner-idx15-stl-lasvegas",
  description:
    "Plan a 3-day St. Louis -> Las Vegas trip (2022-03-29..03-31, 1 traveler, $1300 budget) by reading the local TravelPlanner CSV databases.",
  phases: ["gather", "assemble"],
};

const DB = "[SOURCE_ROOT]/an-z/work/travelplanner-cc-dynamic/TravelPlanner/database";

const SHARED = `
CONTEXT - TravelPlanner offline databases.
The MCP "travelplanner" tool server FAILED to connect in this session, so the
search_* tools are NOT available. Use the Grep and Read tools directly on the
CSV files below. Do not try to call MCP tools and do not run python.

Files and schemas (header row is column order):
1) ${DB}/accommodations/clean_accommodations_2022.csv
   ,NAME,room type,price,minimum nights,review rate number,house_rules,maximum occupancy,city
   -> price is PER NIGHT for the whole unit. city is the LAST column.
2) ${DB}/restaurants/clean_restaurant_2022.csv
   ,Name,City,Cuisines,Average Cost,Aggregate Rating
   -> "Average Cost" is per person per meal.
3) ${DB}/attractions/attractions.csv
   Name,Latitude,Longitude,Address,Phone,Website,City
   -> City is the LAST column.

HARD LIMITS: at most 5 tool calls total. If a Grep returns nothing, try exactly
ONE alternative pattern, then move on with whatever you have. Never loop.

Tip: Grep with output_mode "content" and a head_limit. To match the trailing
city column use a pattern anchored at end of line, e.g. ",Las Vegas$". For the
restaurants file the city is a middle column, so use ",Las Vegas,".
`;

const TRIP = `
TRIP FACTS (fixed, do not re-derive):
- 1 traveler. Origin: St. Louis. Destination: Las Vegas. Total budget: $1300.
- Day 1 = 2022-03-29 (fly St. Louis -> Las Vegas)
- Day 2 = 2022-03-30 (in Las Vegas)
- Day 3 = 2022-03-31 (fly Las Vegas -> St. Louis)
- 2 nights of lodging needed (nights of Mar 29 and Mar 30).
- Flights already looked up from the flights CSV (do NOT re-read that 300MB file):
  Outbound 2022-03-29 St. Louis -> Las Vegas:
    F3612533 $330 20:20 -> 21:52
    F3963080 $389 14:46 -> 16:09
    F3963082 $594 08:34 -> 10:03
    F3569952 $470 18:09 -> 19:44
    F3963081 $607 22:04 -> 23:45
  Return 2022-03-31 Las Vegas -> St. Louis:
    F3570705 $331 00:43 -> 05:50
    F3991094 $374 20:37 -> 01:37
    F3612477 $466 13:34 -> 18:44
    F3991096 $531 14:33 -> 19:30
    F3991095 $681 07:26 -> 12:21
`;

const gathered = await phase("gather", () =>
  parallel([
    agent(
      `${SHARED}${TRIP}
TASK: find LODGING in Las Vegas.

Grep ${DB}/accommodations/clean_accommodations_2022.csv for Las Vegas rows
(city is the last column). Return the 10 cheapest-per-night options that are
VALID for this trip, meaning:
  - "minimum nights" <= 2  (we only stay 2 nights)
  - "maximum occupancy" >= 1
For each, report exactly: NAME | room type | price per night | minimum nights |
maximum occupancy | review rate number | house_rules.
Also compute 2-night total (price x 2) for each.
Output a compact plain-text table. No prose.`,
      { description: "Las Vegas lodging" },
    ),
    agent(
      `${SHARED}${TRIP}
TASK: find RESTAURANTS and ATTRACTIONS in Las Vegas.

Step 1: Grep the restaurants CSV for ",Las Vegas," and return 12 options,
favouring a spread of average cost (include several cheap ones under $25 and a
few mid-range). Report: Name | Cuisines | Average Cost | Aggregate Rating.
We need 9 DISTINCT restaurants total across the trip (no repeats allowed), so
give at least 12 candidates.

Step 2: Grep the attractions CSV for ",Las Vegas$" and return 10 attraction
names exactly as spelled in the file.

Output two compact plain-text lists, restaurants then attractions. No prose.`,
      { description: "Las Vegas food and sights" },
    ),
  ]),
);

const draft = await phase("assemble", () =>
  agent(
    `${TRIP}

DATA GATHERED BY OTHER AGENTS:
--- LODGING ---
${gathered[0]}
--- FOOD AND ATTRACTIONS ---
${gathered[1]}

TASK: assemble the final 3-day itinerary. Work purely from the data above -
make ZERO tool calls.

Rules:
- Pick ONE hotel for both nights (same accommodation on day 1 and day 2;
  day 3 accommodation is "-"). It must have minimum nights <= 2.
- Pick a sensible outbound flight that lands early enough to allow lunch and
  dinner on day 1, and a return flight on day 3 that is not the 00:43 red-eye
  (prefer an afternoon/evening return so day 3 has meals and an attraction).
- Every restaurant must be DISTINCT across the whole plan (no repeats).
  Day 1 breakfast is "-" (traveller is in transit / departing St. Louis).
- 1-2 attractions per day in Las Vegas, all distinct, none repeated.
- Keep TOTAL cost (flights + 2 nights lodging + all meals, 1 person) UNDER
  $1300. Show the arithmetic.

Output:
(a) a line-item budget table with a total, then
(b) the itinerary as JSON matching this exact shape:
{"idx":15,"query":"<verbatim query>","plan":[{"day":1,"current_city":"from St. Louis to Las Vegas","transportation":"Flight Number: F3963080, from St. Louis to Las Vegas, Departure Time: 14:46, Arrival Time: 16:09","breakfast":"-","attraction":"Name, Las Vegas;","lunch":"Name, Las Vegas","dinner":"Name, Las Vegas","accommodation":"Name, Las Vegas"}]}
Day 2 current_city is "Las Vegas" and transportation is "-".
Day 3 current_city is "from Las Vegas to St. Louis" with the return flight.
The verbatim query is:
"Please arrange a 3-day trip for me departing from St. Louis and visiting Las Vegas from March 29th to March 31st, 2022. My budget for this journey is $1,300."`,
    { description: "Assemble itinerary" },
  ),
);

return draft;
