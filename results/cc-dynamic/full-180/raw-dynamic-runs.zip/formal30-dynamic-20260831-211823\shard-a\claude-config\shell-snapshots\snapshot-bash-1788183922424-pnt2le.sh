# Snapshot file
# Unset all aliases to avoid conflicts with functions
unalias -a 2>/dev/null || true
shopt -s expand_aliases
# Check for rg availability
if ! (unalias rg 2>/dev/null; command -v rg) >/dev/null 2>&1; then
  function rg {
  local _cc_bin="${CLAUDE_CODE_EXECPATH:-}"
  [[ -x $_cc_bin ]] || _cc_bin=/c/Users/lbq/.local/bin/claude.exe
  if [[ ! -x $_cc_bin ]]; then command rg ${1+"$@"}; return; fi
  if [[ -n ${ZSH_VERSION:-} ]]; then
    ARGV0=rg "$_cc_bin" ${1+"$@"}
  elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]] || [[ "$OSTYPE" == "win32" ]]; then
    ARGV0=rg "$_cc_bin" ${1+"$@"}
  else
    (exec -a rg "$_cc_bin" ${1+"$@"})
  fi
}
fi
# Shadow pkill to refuse patterns matching the CLI process
unalias pkill 2>/dev/null || true
function pkill {
  if [ -n "${CLAUDE_PID:-}" ] && [ -r "/proc/${CLAUDE_PID}/comm" ]; then
    local _cc_skip="" _cc_a
    local -a _cc_probe=()
    for _cc_a in ${1+"$@"}; do
      if [ -n "$_cc_skip" ]; then _cc_skip=""; continue; fi
      case "$_cc_a" in
        --signal) _cc_skip=1 ;;
        --signal=*|-e|--echo) ;;
        -[0-9]*) ;;
        -[PUGOF]?*) _cc_probe+=("$_cc_a") ;;
        -[ABCDEFGHIJKLMNOPQRSTUVWXYZ][ABCDEFGHIJKLMNOPQRSTUVWXYZ0-9]*) ;;
        *) _cc_probe+=("$_cc_a") ;;
      esac
    done
    if command pgrep ${_cc_probe[@]+"${_cc_probe[@]}"} 2>/dev/null | command grep -qx "${CLAUDE_PID}"; then
      printf 'pkill: refusing to run — this pattern matches the Claude CLI process (PID %s). Narrow the pattern, or target your own children with `pkill -P $$ ...`.\n' "${CLAUDE_PID}" >&2
      return 1
    fi
  fi
  command pkill ${1+"$@"}
}
export PATH='/c/Users/lbq/bin:/mingw64/bin:/usr/local/bin:/usr/bin:/bin:/mingw64/bin:/usr/bin:/c/Users/lbq/bin:/c/Users/lbq/.codex/tmp/arg0/codex-arg0z6zjjd:/c/Users/lbq/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/override:/c/Python314/Scripts:/c/Python314:/c/Program Files/Microsoft MPI/Bin:/c/WINDOWS/system32:/c/WINDOWS:/c/WINDOWS/System32/Wbem:/c/WINDOWS/System32/WindowsPowerShell/v1.0:/c/WINDOWS/System32/OpenSSH:/c/Program Files/dotnet:/d/software/Xftp7:/cmd:/d/Program Files (x86)/Microsoft SQL Server/160/Tools/Binn:/d/Program Files/Microsoft SQL Server/160/Tools/Binn:/d/Program Files/Microsoft SQL Server/Client SDK/ODBC/170/Tools/Binn:/d/Program Files/Microsoft SQL Server/160/DTS/Binn:/c/Program Files (x86)/ZeroTier/One:/d/software/texlive/2024/bin/windows:/c/Program Files (x86)/sbt/bin:/d/software/Nodejs:/c/ProgramData/chocolatey/bin:/d/software/cursor/resources/app/bin:/c/Program Files/GitHub CLI:/c/Users/lbq/bin:/d/software/Eclipse Adoptium/jdk-11.0.27.6-hotspot/bin:/c/Users/lbq/AppData/Local/Programs/Python/Python312/Scripts:/c/Users/lbq/AppData/Local/Programs/Python/Python312:/c/Users/lbq/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell:/c/Users/lbq/AppData/Local/Microsoft/WindowsApps:/d/software/PyCharm 2024.1.4/bin:/d/software/Microsoft VS:/c/Users/lbq/AppData/Local/Microsoft/WinGet/Packages/astral-sh.uv_Microsoft.Winget.Source_8wekyb3d8bbwe:/c/Users/lbq/AppData/Roaming/npm:/d/software/rust/cargo/bin:/d/software/PyCharm 2025.3.2/bin:/c/Users/lbq/AppData/Local/GitHubDesktop/bin:/d/software/Golutra:/c/Users/lbq/AppData/Local/Microsoft/WinGet/Packages/marlocarlo.psmux_Microsoft.Winget.Source_8wekyb3d8bbwe:/c/Users/lbq/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback:/c/Users/lbq/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd:/c/Program Files/WindowsApps/OpenAI.Codex_26.818.5345.0_x64__2p2nqsd0c76g0/app/resources:/usr/bin/vendor_perl:/usr/bin/core_perl'
