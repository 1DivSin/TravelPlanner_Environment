---
name: travelplanner-mcp-and-workflow-broken
description: In travelplanner-cc-dynamic the Workflow tool spawns 0 agents; the travelplanner MCP server DOES work (as of 2026-09-03 later runs).
metadata:
  node_type: memory
  type: project
  originSessionId: b037378a-f0b1-43d0-b0d6-4333a1a2a8ec
  modified: 2026-09-03T03:47:15.257Z
---

In `travelplanner-cc-dynamic`, as of 2026-09-03:

1. The `Workflow` tool still returns `agentCount: 0` after ~30ms with no `journal.jsonl` — the script body never executes, with or without a top-level `return`. Phase labels still render because they come from `meta.phases`, so a run looks partially successful when nothing ran.
2. The `travelplanner` MCP server now DOES connect. `search_flights` / `search_accommodations` / `search_restaurants` / `search_attractions` / `compute_distance` all return data. This is a correction to the earlier note that MCP was down.

**Why:** Workflow-based plans silently produce nothing, so budgeting a whole turn on them wastes the run. But MCP is the fastest path to the data and no longer needs the CSV fallback.

**How to apply:** Launch the requested workflow if asked, but immediately gather the same data inline via the MCP tools in parallel and compose the answer yourself; verify the no-op by checking for a missing `journal.jsonl`. Use `[[travelplanner-csv-schemas]]` with Grep/Read only if MCP regresses. Bash has been permission-denied in these runs, so prefer the dedicated file tools.
