---
name: workflow-parallel-needs-thunks
description: "Workflow scripts must pass functions (not already-created promises) to parallel(), or the agents get interrupted"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c220a083-bf86-4fbd-bae7-f5aaee8d1f92
  modified: 2026-08-31T13:39:58.666Z
---

In Workflow tool scripts, `parallel([...])` takes an array of thunks (`() => agent(...)`), not an array of already-invoked `agent(...)` promises. Passing bare `agent(...)` calls starts the agents outside the scheduler and they are immediately killed with "[Request interrupted by user]", leaving `journal.jsonl` with `started` entries and no `result`.

**Why:** a whole TravelPlanner run was wasted this way; the failure looks like a model/API problem rather than a script bug, so it is easy to misdiagnose.

**How to apply:** write `await parallel([() => agent(A), () => agent(B)])`. If a run's journal shows `started` with no matching `result`, suspect this before retrying. Iterate by editing the persisted script file and re-invoking Workflow with `scriptPath` instead of resending the script.
